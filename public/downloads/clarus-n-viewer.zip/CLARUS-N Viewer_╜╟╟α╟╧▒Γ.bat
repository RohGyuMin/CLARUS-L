@echo off
rem ===========================================================
rem  CLARUS-N Viewer  -  portable launcher
rem
rem  This PC does NOT need Python installed.
rem  The first run downloads a private Python into .\runtime
rem  next to this file. Nothing is installed system wide.
rem
rem  Usage:
rem    double click                       demo phantom
rem    drag files onto this .bat          open those volumes
rem ===========================================================
setlocal
cd /d "%~dp0"
title CLARUS-N Viewer

if not exist "clarusn_viewer.py" goto :NOTEXTRACTED
if exist "runtime\python\pythonw.exe" goto :RUN

echo.
echo ===========================================================
echo   CLARUS-N Viewer  -  first time setup
echo ===========================================================
echo.
echo   Python does NOT have to be installed on this PC.
echo   A private copy is placed in the "runtime" folder next to
echo   this file. Nothing is written to Program Files, the
echo   registry or PATH. Deleting this folder removes it all.
echo.
echo   About 200 MB is downloaded. Takes 3 - 10 minutes.
echo   This happens only once.
echo.
pause
echo.

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup.ps1"
set "RC=%ERRORLEVEL%"
if "%RC%"=="0" goto :SETUPOK
if "%RC%"=="2" goto :NODOWNLOAD
if "%RC%"=="3" goto :NOPIP
if "%RC%"=="4" goto :NOPKG
goto :SETUPFAIL

:SETUPOK
echo.
echo Setup finished. Starting CLARUS-N Viewer ...
echo.

:RUN
rem Other Qt programs (3D Slicer, Anaconda, ...) can leave these
rem set to a different Qt, which breaks the window creation.
set "QT_PLUGIN_PATH="
set "QT_QPA_PLATFORM_PLUGIN_PATH="
set "QT_QPA_PLATFORM="
set "QT_DEBUG_PLUGINS="
set "QT_SCALE_FACTOR="

start "" "runtime\python\pythonw.exe" "launch.py" %*
exit /b 0


:NOTEXTRACTED
echo.
echo [!] clarusn_viewer.py was not found next to this file.
echo.
echo     The batch file was probably started from INSIDE the ZIP.
echo     Windows then copies only the .bat to a temp folder.
echo.
echo     Fix: right click the ZIP, choose "Extract All...",
echo          open the extracted folder and run it from there.
echo.
pause
exit /b 1


:NODOWNLOAD
echo.
echo [!] The Python runtime could not be downloaded.
echo.
echo     This PC needs internet access for the FIRST run only.
echo     A company proxy or firewall may block www.python.org.
echo.
echo     If this PC has no internet:
echo       1. run this program on a PC that does have internet
echo       2. there, run  make_offline_copy.bat
echo       3. copy the ZIP it makes to this PC and extract it
echo          - it will start straight away, no download needed
echo.
pause
exit /b 2


:NOPIP
echo.
echo [!] pip could not be installed into the private runtime.
echo     bootstrap.pypa.io may be blocked. See the note above.
echo.
pause
exit /b 3


:NOPKG
echo.
echo [!] VTK / PyQt5 / numpy could not be installed.
echo     pypi.org may be blocked, or the download was interrupted.
echo.
echo     You can simply run this file again - it will retry.
echo.
pause
exit /b 4


:SETUPFAIL
echo.
echo [!] Setup stopped with code %RC%.
echo     Copy every line above and send it back.
echo.
pause
exit /b %RC%
