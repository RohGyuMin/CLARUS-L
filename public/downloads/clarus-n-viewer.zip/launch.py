#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CLARUS-N Viewer launcher.

pythonw.exe 로 실행하면 화면에 아무 메시지도 남지 않기 때문에,
시작 도중 문제가 생기면 error_log.txt 에 기록해 둔다.
"""

import os
import sys
import traceback

HERE = os.path.dirname(os.path.abspath(__file__))
LOG = os.path.join(HERE, "error_log.txt")


def _write_log(text):
    try:
        with open(LOG, "w", encoding="utf-8") as f:
            f.write(text)
    except Exception:                                    # noqa: BLE001
        pass


def main():
    if HERE not in sys.path:
        sys.path.insert(0, HERE)
    try:
        if os.path.exists(LOG):
            os.remove(LOG)
    except Exception:                                    # noqa: BLE001
        pass

    try:
        import clarusn_viewer
        return clarusn_viewer.main(sys.argv)
    except SystemExit:
        raise
    except BaseException:                                # noqa: BLE001
        header = (
            "CLARUS-N Viewer - startup failed\n"
            "python   : %s\n"
            "exe      : %s\n"
            "folder   : %s\n"
            "%s\n\n"
        ) % (sys.version.replace("\n", " "), sys.executable, HERE, "-" * 60)
        _write_log(header + traceback.format_exc())
        # 콘솔이 있으면 화면에도 보여 준다
        try:
            sys.stderr.write(header)
            traceback.print_exc()
        except Exception:                                # noqa: BLE001
            pass
        return 1


if __name__ == "__main__":
    sys.exit(main())
