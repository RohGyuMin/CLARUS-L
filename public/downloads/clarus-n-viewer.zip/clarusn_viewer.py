#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CLARUS-N Viewer
===============
원본 볼륨(original)과 annotation(segmentation)을 함께 보는 뷰어.
3D Slicer 와 같은 4-pane 구성(Axial / 3D rendering / Coronal / Sagittal).

    · 입력  : NIfTI(.nii, .nii.gz), NRRD(.nrrd, .seg.nrrd, .nhdr), DICOM 시리즈 폴더
    · 2D    : vtkImageSliceMapper 3면 + label color overlay + crosshair 3면 연동
    · 3D    : vtkSmartVolumeMapper 볼륨 레이캐스팅 + label surface(Flying Edges)
    · 방향  : NIfTI 는 sform/qform 을 읽어 R/L/A/P/S/I 를 자동 결정 (RAS/LPS 수동 전환 가능)

설치 · 실행 방법은 README.md 참고.
"""

from __future__ import annotations

import base64
import os
import re
import sys
import time
import traceback

import numpy as np

# ---------------------------------------------------------------------------
# Qt 플랫폼 플러그인 경로 고정
#
# Windows 에서 3D Slicer · Anaconda · 그 밖의 Qt 프로그램이 PATH 에 자기 Qt DLL 을
# 올려 두면, PyQt5 의 qwindows.dll 이 남의 Qt5Core.dll 을 물고 초기화에 실패한다.
# 증상: qt.qpa.plugin: Could not find the Qt platform plugin "windows" in ""
# 그래서 PyQt5 가 들고 있는 plugins / bin 경로를 명시적으로 지정한다.
# 반드시 PyQt5 를 import 하기 전에 실행해야 한다.
# ---------------------------------------------------------------------------
def _prepare_qt_environment():
    try:
        import PyQt5                                   # DLL 은 아직 로드되지 않는다
    except ImportError:
        return None
    root = os.path.dirname(os.path.abspath(PyQt5.__file__))
    qt_dir = None
    for cand in ("Qt5", "Qt"):
        d = os.path.join(root, cand)
        if os.path.isdir(os.path.join(d, "plugins")):
            qt_dir = d
            break
    if qt_dir is None:
        return None

    plugins = os.path.join(qt_dir, "plugins")
    if os.name == "nt":
        # 다른 Qt 앱이 남긴 값을 덮어쓴다
        os.environ["QT_PLUGIN_PATH"] = plugins
        os.environ["QT_QPA_PLATFORM_PLUGIN_PATH"] = os.path.join(plugins, "platforms")
        qt_bin = os.path.join(qt_dir, "bin")
        if os.path.isdir(qt_bin):
            os.environ["PATH"] = qt_bin + os.pathsep + os.environ.get("PATH", "")
            if hasattr(os, "add_dll_directory"):
                try:
                    os.add_dll_directory(qt_bin)
                except OSError:
                    pass
    return plugins


_QT_PLUGIN_DIR = _prepare_qt_environment()

# --- Qt binding (VTK 의 Qt 위젯보다 먼저 지정해야 한다) ----------------------
import vtkmodules.qt                                   # noqa: E402

vtkmodules.qt.PyQtImpl = "PyQt5"

from PyQt5 import QtCore, QtGui, QtWidgets            # noqa: E402

if _QT_PLUGIN_DIR:
    QtCore.QCoreApplication.addLibraryPath(_QT_PLUGIN_DIR)

import vtk                                            # noqa: E402
from vtk.util import numpy_support                    # noqa: E402
from vtkmodules.qt.QVTKRenderWindowInteractor import (  # noqa: E402
    QVTKRenderWindowInteractor,
)

APP_NAME = "CLARUS-N Viewer"
APP_VERSION = "1.6"

# ---------------------------------------------------------------------------
# palette — PPT 시안의 색
# ---------------------------------------------------------------------------
C_GROUND = "#08122b"
C_CHROME = "#0d1c3f"
C_RAIL = "#12244a"
C_RAIL_HI = "#1d4682"
C_EDGE = "#22406f"
C_INK = "#e6eefb"
C_INK_DIM = "#8fa6c8"
C_ACCENT = "#cc66ff"          # CLARUS-N 의 'N'
C_AMBER = "#ffc000"           # VIEWER
C_TAB_ON = "#2f7cc6"
C_VIEW_BG = (0.012, 0.024, 0.055)
# 3D 뷰 배경 — View 메뉴에서 고른다
BG_PRESETS = {
    "Blue":  ("gradient", (0.459, 0.475, 0.749), (0.749, 0.761, 0.906)),  # #7579BF -> #BFC2E7
    "Black": ("flat",     (0.012, 0.024, 0.055)),                         # Axial 판과 같은 검정
    "Navy":  ("flat",     (0.051, 0.110, 0.247)),                         # 메뉴줄과 같은 남색
}
BG_DEFAULT = "Blue"

# label surface 음영
#
# shade 0.0 = 평평 (1.4 버전, 색은 또렷하지만 원근이 잘 안 보임)
# shade 0.5 = 기본값 — 1.3 이전의 강한 음영과 1.4 의 평평한 음영의 중간
# shade 1.0 = 강함 (1.3 이전 버전)
#
# ambient 는 그늘의 밝기, diffuse 는 빛을 받는 쪽의 밝기다.
# 예) shade 0.5 → ambient 0.28 / diffuse 0.72 이므로
#     보는 각도에 따른 밝기가 기준 색의 28 ~ 100 % 사이에서 변한다.
SHADE_DEFAULT = 0.50
LABEL_SPECULAR_POWER = 24


def shading_params(t):
    """shade 값(0~1) -> (ambient, diffuse, specular)"""
    t = min(1.0, max(0.0, float(t)))
    return (0.56 - 0.56 * t,          # ambient  : 0.56 -> 0.00
            0.44 + 0.56 * t,          # diffuse  : 0.44 -> 1.00
            0.02 + 0.26 * t)          # specular : 0.02 -> 0.28

# 3D Slicer 세그먼트 기본 색 — Segment_1~5 는 Slicer 값 그대로,
# 6번 이후는 같은 계열로 이어지는 확장 팔레트.
SEGMENT_COLORS = [
    (1.000, 0.702, 0.502),   # 1  #FFB380
    (0.902, 0.302, 0.200),   # 2  #E64D33
    (0.800, 0.000, 0.800),   # 3  #CC00CC
    (0.400, 0.902, 0.800),   # 4  #66E6CC
    (0.125, 0.655, 0.231),   # 5  #20A73B
    (0.302, 0.580, 1.000),   # 6  #4D94FF
    (1.000, 0.839, 0.200),   # 7  #FFD633
    (0.702, 0.400, 1.000),   # 8  #B366FF
    (1.000, 0.400, 0.600),   # 9  #FF6699
    (0.000, 0.702, 0.702),   # 10 #00B3B3
    (0.651, 0.369, 0.180),   # 11 #A65E2E
    (0.549, 0.851, 0.549),   # 12 #8CD98C
    (1.000, 0.502, 0.000),   # 13 #FF8000
    (0.400, 0.400, 0.902),   # 14 #6666E6
    (0.902, 0.902, 0.000),   # 15 #E6E600
    (0.800, 0.400, 0.600),   # 16 #CC6699
]
# 이름을 바꾸고 싶으면 여기에 {id: "이름"} 을 넣으면 된다. 비워 두면 Segment_N.
LABEL_NAMES = {}
MAX_LABELS = 64            # labelmap 에서 읽어 들일 클래스 수 상한
MAX_STUDIES = 20           # 동시에 열 수 있는 파일 수 (탭은 2줄로 나뉜다)


def label_color(lid):
    """클래스 id -> RGB (0-1). 팔레트 길이를 넘으면 순환한다."""
    return SEGMENT_COLORS[(int(lid) - 1) % len(SEGMENT_COLORS)]


def label_hex(lid):
    r, g, b = label_color(lid)
    return "#%02X%02X%02X" % (int(r * 255 + 0.5), int(g * 255 + 0.5), int(b * 255 + 0.5))


def label_name(lid):
    return LABEL_NAMES.get(int(lid), "Segment_%d" % int(lid))


# 드롭한 파일이 annotation 인지 판별할 때 쓰는 파일명 단서
# CLARUS-N VIEWER 워드마크 — 원본 이미지에서 배경을 투명하게 분리한 PNG
LOGO_PNG_B64 = (
    "iVBORw0KGgoAAAANSUhEUgAAAf4AAAAwCAYAAADw+hhVAABUdklEQVR42u29eXzU1fX//zz3/Z6ZJCQgq4KKSAUrSfvRQt3q"
    "kli0aks3O1OtbV0Ln+JWl08Xl86MtnZxadXWCu7WrTO21qq4mwEUUUO1mkQNCgiyhj0hy8z7fc/vj5lACAnZAfv9XR9vQybv"
    "ed/7vst5nde555wr9FFRVQM4gLBwoTBuXLu3AZokaSMS8XtRlwCu7zMdcB2HW0Ukw39ZyWimVHw52HE2PiIybLOqiohof9ap"
    "qrJwIcG8PAzA/vujS5a0c+OYbrwHaBq0CXQSeLR+B0W628YoUYkR0wYa9s2j4McWKlz4VwqkDPzdMVbl4JQCPnxHYEID/KkI"
    "aqMg8ey873pp1T8JVWcsC0weeRIkKAECsuNQjGEhCxVgM5vtIhbtsL6iGjVx4n03d6Tr76RRNc+sJ3DIZmTJGLyyuHh9PGu7"
    "NYfCYUwYgrlf/UiSzA5SapcV2R0P0z550dj29UW7+fXq6p6//IQJXW98vC97OIa2fe/uya5+LrFtP5LJjtvZrRdoCzyqmp8D"
    "+6Mt9gysKQFGGBiCobD1dy3Wx5rlwFprvErg0U24rw6FjIg0dlRHewqGiFjf178aw/cBrOXvjiPf2RXA2Dv51LX+VpRmr/m0"
    "kBtKZjvPPoExp7V0Zd+84/bCsrwcp6xMPE3rUQTsg2DG9tVrW8tqYDPGLlJf53qOkwitYkVyH5oiIn5uYKWLC0fiIrZedWQ+"
    "9jmD+RzQ7MPPXZE/VqoGS2CXKoGVECgRSXvqXe3gRAEX7JubMF/ZS2RDVNV0Cfxz47pUNX//tbgM42DgLOAQa+0BYILGMLqD"
    "Pl4P1GPsx0C1wbzIOp5n6BoLtzeIxG22m6OGnALQa8jpBPzLo+qWxcWrmKpftXDn4BAjNzSTyhi++6U7ZI2iInR1LmsfIGS2"
    "rtfP07Drkgg50JThhUl3ykmzLtLQqbeS3vVCQXaZVtB1+IlpfwB+b4C+LxWBflMKdhfYtwL8rhZ3Kxh1QYMXEY1q1MSIDQQ+"
    "D/Yi4CQwAw2GLEekCfCAVa1USjGYPAwjgNEG9wvADweDb619TlVvAN4G6qQFCDovfqvne+yJpZtsNkpU4hK3W3TLPgPcAb/a"
    "+gdjjk376XDIDT1aqZVBtANg2+kY7lxwFhVl2+oFvEEuZmCubz1gM5DOCaEuLy4LYkAtBIxhEDAYzDgcvuLAr+wIar6Jf/Mm"
    "1ccGiaxDRLsMkNuK1+qn3QNG3AKegitdnJMtikxOqR2UyWQmOHA5QzgRGLhtCph07vm1ufeVVuwtzxjys/eb0cCxwDQGW2vt"
    "iLeMid2vGnsEaBSRLS0KtLYCXenN/O5g3hWtzP7d99jLOORvakZdKPU8pgB3S58BenfWmBqUg51cmy2MAlg9BNk9UyYqex4E"
    "xaRdZaAHTLc/wb6jerqjBET5lJZY777udgZSLWCUExaDfZhirb3SGHNwDunTwEfWsshgl2HMbGCliLzQ+jnNWvf5IIX/Y7GH"
    "YRmH4RAD+2PMqcCp1rJQld+p6uMisr4L7F9aySvZowZFe9aeOHGNatS4uMcABwP1WFuPMfu44p6kqo8vYYl0vd6eGQYsWANi"
    "sSsbMFOKRN7paVfUqhYNhm+CP0CtHGsw+xvswcaY8QbnDsfaq1X1x8AzIuJ3lfm3Gfc9afxFutSmmESJERexqhr04BiwfwwE"
    "Ap/LIj3WWrsc5SMcPlHMbAca17Dm8b1l7/o2VrCDffzDgM8Ish/WfNYYxmDM3gYmAhOt9X+Hce5u1Mab8shbKtl6Tcsk0d50"
    "4jYFYLuyaMP2n7iCZCzNAcOM+edr1ZF3yfxoVE08vmuN6zlFRXICpJ/rjnWxW6P9xEGjfddrsXaeHNu9gN+XSsB/M9B3DPzt"
    "lAQJ07JX2KiNJ1trr3SMORZjANZZy5tqeNWBGx1HmtoII7eNteAd4B3gry1/t9hrDJwEfN4YxgF3+T7nquqvRWSWiGiLaf9T"
    "MTjam72frII1dfPUoYGiwPW5jxdgzD3A/caYr/r4Xz9QDkxWamWwhJLMzhrSR8WEYKCqukvAXdeD/fNyaIiI/DX36x0AWzR9"
    "ZAFcBuYkY8x+wJMZ379a16//k4hs6ib455QVXwCWslDgoV0qdJZyZrv1bWaTAFSTFKja7m9hiiUu4m/UjUOs5eeu4f9yinTG"
    "Wt4DXk6b9C35kr9ku/7UcrdSK4PbS2SpQfhgB3OI513hOM7RwERjnNHAhUEb/KFv/Kt0oz7cSsE2gGpvtaidaw8adCGTphrY"
    "z4WHXjtbTz4qLgujdNvS08tZvTsBvjtAHe+j5/Q94kQ7+HN1EiHZNzWH2/msu49uUQL2KAUgtvub4O4MiCIS8Zeq5o/CP9/B"
    "uQWDAGlrecPa5psCgbx/tggjVQ2QddzTMGEV2d6BJ+eQt93liBNV1euAn1jL94zhMMfhaOBpVb0UmCkiDf/NgN+a7auqSfvp"
    "EwxmHOD5vv9Yo9P4bIEtXGQMYx1ksqrOWshCL0pU2nfW0j6F/wD4IuKVq9ITx7koSELVGQ5SBJIHMkBkPhDxVH8ocKOB4QHH"
    "+RWDB39+ta4+b2+R+m1m/+0FajXFAtBIg+ST96lT3KO5VR8X8Tdp0/iBBKIYvgdgLcuAR5tMwy0DZMDyci13a7QmlCatTTRp"
    "HXVaS62mSHltFfThOlyKKJIWJ8A0aXXFvRGgSZvGhQhdg7VHG2M+A9xGESc3a/M1IQm9BWiMmBMj5vcB++/oy9lVYqm3yi8d"
    "l+vcoL2zYqp+Y9JM2bTLTP5RYMWeBPTdBe94fzH6LiFUR7VVt3YkC3fx8cmu39rdR7dVFKqrEcIwIbwnWwBirS7a/OxbbcFt"
    "f4UqOVPgSA/7cwfn4iyrYjnW3r3cLP/taGd0Y43WhDaz2T7Jk34ZZdrGlNbG/inaFotyVgERkRtV9RGL/S2Wk40xw4A/eNaO"
    "VdXfAKv2SKc97UNzlqDrdF3RYGfwb3Oys9px1t1XJHvXq3o3g/MnMN/y8J4dL+Mfr9TKYJx4pu249VcpbTN4XX3xHJPbrmEJ"
    "VedYyHNFHsiorgfuNjAMiAz2B/8b+F0cUQgbmKB77iJtW5w2vw/aKq6iOZGV+5b+XBsPDBJ4HMyE3E3vGcOFIvJypVYGa3RW"
    "6G1qvRSpTh0Vq6jS9vS8Sq0M1lJr8sj7EOGHzaqHuZabjOEoDF91rXuop95lIpJQVZskaaqo0hgx7Q/wtxbEYS9/A/czCPJc"
    "85dmy/9Fo/rLGCD9afLv1QvtSrDfVUy+n0C/OwCeQ/EXX9y5DWbkSLS4uGdzI7yjJiAA4Q4UgNhukRsd/T3Wpe/Fe1DXDsCf"
    "IGFExG/UxoMs9g4X82VArbX/sdb+NBAIvFCu5W6FVgTGMz7dKSDuxOGsxSqgqgERWQ78wPO87/mWqxzDBNeYi8AG4b2LgbSq"
    "7jl7udq3e1iqatKkv2owB1rIWN9/0HX3rldVqWtufmlAQKqMMcUu7omq+nIVVY0trF/7jN93T452VwloKRGwiGxZrloQEHmq"
    "SfVHIbgfKAo4gd82auaNPNw5MdD4nmAX20kbosBB7Xxu2eaZFyZr6K/OKrk+COrbGIYJua58N53m7FBI3lquWvAqyeYcmPeq"
    "JEl6AOWUO0VaFAyJvKWLF59qR4++zhhzvjFmX+Avnnoh4OHhDJdiioll/+s9+EfaBf+0k8f+R9wld8w/X48tcLnq5OV8KHfJ"
    "ff2239/rJ8b2LB+iPQj0u1smVGWn1Isruz61Vq5EVra6f+TI7Ij2VBmAbKhbe+Af67VE6PtvdQ3ku1pfbEfgbzHvb9ANewUJ"
    "3m6yoO8DszMm8+M8J69muS4vmMnMpi7HBCvSWcSAiGRy+4whEXlYVd+y1l6FYbDBLCBn3v1vBPwW5WiFrsjfx+7zWwyKtR86"
    "Tu3t5VruxojZeF78fVWdAdyaFaferBIpeapGa0Ix4ml2s/WqR0qARs2+xJr+pcsL8kT+lfH9B1xjLgD8oHVvWGjWnRCXYZvR"
    "hEMfgGBfAn2PhR6oqroeHA/8EFDf5xNruSgUkreWqubvC41RwpJVF/pG6UmRskBT1jdgTMYR+T9PvdUOzlXAEAfn9x7e+jIp"
    "ezqhCSfbAzGJdRbW1aOpDr4hrWF13s5wVbOhxHH44/yz9N0j47IgG+L3/4P+pwX0u8r2WwB/5crey8+2z+ipAtAR+PcOUvsH"
    "9ON9PL5m+49iulJ1QKEd+GuDOTHLXOy8JprOy5O8mnItz9tX9m3odiKQLoCliFgRacyx//ccx/m+I85XReROEWnO3bO7Ea5f"
    "hEBUo2Zv9v6OMWY04KnqXSIjtxRRJKWUmpyl43ngP8BQMKds0k1Dx5HWXR0O1RU5q50K0m3CdAE1aVUNbcpkZljf1gDGGCbu"
    "mxk4ISt0diXoxzoUfNE+YD1xEbtw4ULH+PaWnELti3BfMChzVqoOGA1N0e10p761diRJegtYYCq0IuDg3Az+DWSjcvZxcb86"
    "Q2cEIhLxi3OKdoxY7xbchPY/tg4qSfEPu1+W+IYLDfhuiIdf/b6OMPThGv/v8Of+rwD9tqy9L0rLM6uqev7cZLLv2hTrUILs"
    "KaC/rZgWpo+gIqLD8H7mGjM9B/o1BnNJvuQvqdGaUJmUNfUY/Lr4vRz7d7RCA6pqVNX5r2X6ZPfliyl2HSu/ImshXuw4q+9Q"
    "VWcSk7wyyvxst8gHwD1ZwDDfG+gFJ4mUpOkkMmNPsALsjD3FSdnXWGaG5eVVG+EVmw3H9wsCgf+dp0vzW0JJd7XQ6yuw375T"
    "VMaMGVNiHFNM1iFgkTHcV6MamrsD6O9cGelpeZIntzpormXDbT7+T3KWpL+PZ7y23U7rNfjvpMy6SENH3iFzfeVqRxgfKOBm"
    "BWZM3VPm9P9rbL9vQT/cCvT7s529Bf9do0LtOaC/FfhjxFRV3YxmylzcKwAP7Jq0l54uIm8t1sV542V8c3+BXzvg78tE8QDt"
    "RkKfTx3ot5Rv8O0fYsz+gPV9/iSyb0OKVCtWvMBRVWmA+cBSYC+M+01VHZ5TFvZIAaUdsPy25RM2+6oqGaP/BhpyoFg2mkEF"
    "u5rl9znYt2L75eA4TiDMtmRDVSKyKABS1Sk/7VvwT5KU4Qyvd8X9i4hcIiIvpUjZGDFp618Q6y0AmvazP70+hMyMiRq4cQMz"
    "PZ97BwQ487WpevG0mZLpNfjvBhN/lJQJJ6t321qMkjJhtq8/mkqZaCplurYOugb63QVlgOLiZzptQ3HoGVMcesb0pp62Zfjw"
    "lIwdO7PzZ6ZiBpLSP/JlzytulKiIiEXx1fo3k80A1uTj/zk/kP/SYl2cdyAH9h70pbv5ylHZnXi2C5QcRUmSNKfZ036ZTdjC"
    "x47DnarqCNsUnid50q+jzplAaXUB/B24AuOe6eElAhIoz4VS7nHZC2PEpCtpSZJU+2Npcicw8WkHfkI2edEwF+NmmUOxJPvJ"
    "5L8rM3ftCw7GTiCbCMN61i5XVbNwNxilq6jSBAlzqB7q5pFn1rDGa20NaA9He7wgLDsGPOTKigX4iQXo6+fzy4Y0BwWEG948"
    "Tz/84kyZVX68umWze3j2QrfyTPa+hKmWuMzxji8/zt1dkShxmZOVAfrLrUAXL5vjoVbCREyynXaFqZZLX3styH7Pbf1sv07q"
    "WbNmmEzZWULvFTByFNS8O9GSCxG95JJT0vdG7wu9tvLsDsfzkttOSRPG3LLPM25V8yl9ZumbNGl6prx8vFtbW6odgb6UXeep"
    "+q2SwsUMrz0XYD/gky50Srvy7xOWbWM32/ovuLf35MSv7dAPZz7zUCCvpCl7RgrwGvCVzir5BJpHOtqYCWh9OqhVxcNtnNJO"
    "+86NEdMz9czQWMaejjGHkvXgr2owTbcv1sV593Ff7/NXy6dst20XgH40l6rzm3z7f3NJbKyqf5OI29TiYLXN3BPXKUyRvUXq"
    "05p+PEDgdGA/F/NdVa0G1u56Udc56LcF2HiHwF+lP+NLgQKRZZ7q5tzHBQYx/TsGu7YEsmmMW5IPWGtsk4hja3T3DFsVVVpF"
    "VaYLY9lvDcyFe0r8Lvlk3lS9IATl1jDzlfObv3bMXfJ2IqxOJMken8ArKY/59bN15A3Hla4eQbUkdxH4R3Pj88zCccHjZucP"
    "SQ8INQwhtjlKTOIxqHtVR3gpSQ8uk42tFYLW7U5CY/eSG3RVPD5POBwOkiz2G2YftF/B8UuXHX/82e7BB2//gA8+QL/97Wec"
    "+opr9tm0ojCz79fnrb3llidCVVW9B/99G//haPl+w6Rs8qry8hfbBX8pu87T8r2HsaS0Xg6c26Tl17hSdp3XezLV0RRYTlS/"
    "tsNYjD/1o+bez4j3mFWzPPR6Oqjx4nCH7XdFRBGa1frXkXU48tToIwNl4NpcrHjPJrB8Cl1rdNeZGIopFkGs4v9fVtliqeM4"
    "9yQ04USI7DDhJzHJq9CKQIDA29byN2O4HMwPyGT+KsHgatWKAEzcI1h/T0zDaXxVVWNz3FD7JO56zwD8NuQ3kFvxxrVukP/m"
    "Ut118E+E1Tl6prw7f6p+r8DhOfWCN1RM1fMmbmB5NIrs8rS+xLTr5v6Y6ru/2591TclYefxeOUFmhBPfcZLh/gf/aqpFxNjm"
    "ue5BQSczI29Lw18RMyNVfpzz3omV+YUeVyEyfMu8vP8bINcuj5Yf58ZLS22YakkmobZ2SNGw6nXXWZeRJsNeFozpRHbbTsKq"
    "DXg2H9c0Bx6Q44ofyrw04GSXxqszc/Kvvf2tZ8r/sf4U/+CcaX7kyCqZOfOwzH0/ObVwQMPbVw4otPs0PDv2stdDp6xcv77K"
    "rFxZ3LP4/TB2wcyZ7rhht1+F2MO15ouR1HIahg9PSQv4TyDmFIdjnqYKDkFX3cKy1SmtPO1GkjFP515fjO+dR5ADaKYI6Tw6"
    "bWfAb22rfzrOnwLEngZIJCNm+PA1Ulaa8nX2deeB/ZKF/VBkp+OQzasuJptQb7Fx+Mi3LG8aVjCncPxHqwBm1TwUunfcYV57"
    "Sqgb1ai50r/yDDD75xr4b8c491ZqZbAlDvi/DuB3I+DDtlTInno/zfW7Mca/XsRtbsv2W5dFLJJJMqmhIZ1+It8EwsBoAs7Z"
    "qvUfwaxaeFLoR3bWW9DfGeuHbGSHr1n6K/0wItEOWrxL9uFUZR34YzAfkA3nM1iGqapZ0iUVJ7a7xnOXzKdIEqtRNRKX5984"
    "X28qDHJ5fTM/kyQXJsIE6MmJi7vIBhYlJmioHts0BIjpOwMTkffZ3N/1hqmWBAn7n7f3GRBcv+YCXL6kyvUAs0tTftEbA4N4"
    "TAI+63reb4Hlo4rqsylsU2uEcMofNk8OwuUS4+n7vpgZjsXvTOVWa3b6d1+wWExjc/6HF130TMA1Q2qs/aTY1YbrLrnkG1+E"
    "tHPw1JbwvmItL0+7W2qrGpqan30vb2jzhcGNH88tKwvd+vYDFw24feWNPbI4i7iqrw8cT8b/KRnmEDgkPbw2ZapzWw8AwcL1"
    "IuJaLdfJDNIT2ShPUxz2pcSx3nH8j1Ool5KWOaj8g275UmU70WkVNNeiKjmCNa75WHOysio8QacsWGQQo7Zcw2YEX9Fac4Wj"
    "pP2d1SeIY7G+odAxOhyrBzvwzQFrG37tv0zKKPfK+I/maeIwp3R4yswu3d7875YSM65wYW6J+Bg7W8RZr6qBEin5dOTI/5QA"
    "/rYFG1bVuhHgXAGIhQ8N7z+gqkbo+FyCKqq8Sq0Mribw5pjsXv+lFn5gCM4QiaxSLXfZ6huguxogunqsbofgr6pi+4nnRzsF"
    "1f4F1ijIJJFMplH/7uYxLUeNPisidpbuzNYf4/+VInFUo2qS1Vw3dhCfzQtw3rypvHX0TLlr1skaOvVZae52+GqvwL9rrD8O"
    "xD+/eYO+4vwE13+a9ZvOTUYeu6mFXfdXfyUBEaP6qnsgrp6Fco97fPTZmpqHQuPFNNt5RYpSj7BBreyoOIlR5jIAn81YecE9"
    "gT92l8nuvNRxb3R1npSt/tB/SW7D0asyL7nfvuBvPNn6rnfeeca55JJvNC9/6POJUXkLfiT45zS+MOqpPPfGpcWhZ5yu7Pe3"
    "JPUBqKpCKypuD9i66d8zLg55e10hB97XXFEx02VR9p6xG2aat7nV07kPjrb+hh+azfJvQsMfETndz61NZQse4jwuJ9hbusfy"
    "pZN+8ohqzLSjL9SxgYxbqjd1Zx6U63HupPkVQwub0iN9Mic6hvOAb/uz9Q45LnF1lJi03X5yJ9XXDzWFhV/ItXZjmvSfc8l0"
    "/P9aCaO7z2uwnHJHRLyM71/pGobnTGMzRErSnbUrTlyLKSYiJU0Nqv/Mh28ZzBgw0+u1/kq4YU32mM+47gq6E+vDcKcgjoiI"
    "+qp9Ou+i3XibXQG2jXm8VWTteowZbAxjM6qnuvDCCHCe3GHN7V7Q7xXbF7qfWJ2WtL2yad739SdSQHkQrn3jR7r88DvlmRlT"
    "NTBt5i50Yo0hxLo2BqoxWcC0FybOnjkHuFwXj767dAn1/cn2kyRsRcWoAupXTUfQjOXeoFxryxePbp051eTIZ7trNWOxAXAQ"
    "Bs6bd3j+Uc1fyVQNr+7Ut2bp0n3afV7rLJabl5XYmQvO9m+5Ze+QCV5/E/4rZ7mm6eyZM4P/mDo1HdgG1KfYRPStYM2o4o17"
    "N+Xf6ASaHjSsOUrKgoseuOHiEAtP2Snrnzx5ex+QeNy1saMPGEbQPwcrs+SoundqZl0cenvRrV62vpSEwytkUonj68ucbIJM"
    "wpfzOXpVrS4uzZMD5zZt7Tujg7X82Dwo9dhpv1S1OYar41JbO9ym2jtGPDtWgdpXhhQNy5Q0JofXdjoOVcXDbVnWqXN19pK3"
    "tTyYtNp8nXG50i+XYcvz9vvJ6KOWNbV28HRDhfnfA4IA1lKT7+QvySXRyfDfVnT3h72VkrL1Wr+Pizmd7N5+7XqzdoaqSlei"
    "GCJEMpVaGVwE8w+Bfxm4GPh+gMAtIvEc64/726Rvd7X0/gf7tqw/Sql5klFNTdo0zsCQ3FxstA1qs8ym+x790V6+ZX+B71LY"
    "XIz5J3AuMMi1XCiOzFqqml8Mtmo3b9X0Gej3apmqkQflw7nn6Bl75TN3S5pr3z1bK9d+wMpEGNNtZ7+u6sCxnrdcQJC7Mvpq"
    "/hWkG19j6bIfzS5bdsOMioMD0ybO8Pt6PiWZoIjRkjmBMYieg+VvAY6fX1lZG0wuGe5lo347L4FWnf5u8PPe0Udf50XV7xRw"
    "Ojp2dztdbzBMngwrV2Lk2Nc3aEoeA52aLi885sIreJ2J225dOWSpRMoO85YmxqT2H/HhO0GTPufjuUfPev3WGzePnFDldLTX"
    "3xb0q6rQRMJz/GBgmiOMxATuB590/ZCt358ypUYojmUaXrrlAGTjNHx5m6FDnxZxVOcdvv17qVgo9XJe/6Z9SRGjw2xVPSgL"
    "Tb43vGyO154zZrt9riMcgAmskWpGqMhjS/RfI6cxcJWaAp06qnnFv2csmHTPtIkVXosFyw1YObZlK8JgP8iBz6dz3z7WTrIR"
    "7TN51OtSQYUrMinj+7GrMIzINen+4TK8rgOlpN0mV1NNRErSaU3/wxCYAhzo4l6+WTdfDkVrt7H+9h7VvaHNkBGABSyQJ3my"
    "X7qwmOEmIuJdqc1HgR2WSy+xyiu03WZ3B9HXznuxHv5tx5JQdUpE0o3a+OsgwVMMZm8Mk33fv9kRuUx1cd5wSr1cit1PH+D3"
    "0SITUFA59l55Zd75evGoQm5dWcevymbLWRVTNQA98PJv1S7bHQIQ68YwC8jRDRWaMk/j28t08QF3RsZMrguTlCRh7VOlUq61"
    "8+btmx9qXn4Jgs043Bk8bo43Q78QINW7/o93YQ1NCKNdzdxXVXWKnTE1HWjKHHBbnrt0aoCNF81cEHwl+rW3gi2AXlV1ir3l"
    "lidC+1edstIfnH+T4zbdM7yx4sRwkmTejGToqZXFmc5AP8v2UZ01bih4F1pLuRn2i6e0YlQguWjqVuVrIgsQcVRf4iQCfMHP"
    "yFSneM1qTUSCDMSHN7ooEWJ9s9bqUtutuZHNTstc6dJaTG5tR5bNJxKHBOUb7zXo3CEX0LTufxzs9V/1ax5DzLqwfsckmaCu"
    "xRySw/0mjEnlTnj7dO/t684/lt3SJBXA26K1o4zl24BYy5rlZtlvs+6iXd+7jBDxFuvivFd59dVj7HEvusb8yGC+J2n5nYSk"
    "NqpRJw422qlkjrbS1MO7tFtax/cPZ4BRVfEsn7cw0BgwhqqNNHU5vMXslonWsuDOzP3MuvRsK5u2Ls2cKVATmnDyJX/RlvSW"
    "bxY4BfMwBIzhEvV9FXEuj0ajZkpsirOIRbZqF59RsCeAflue3ryQO9cfzBeGFHDWvB/p25Nmyh/uPUvzzrmfHoQ+qVRXIycP"
    "6sEwx7pgUbK+iYtjKc+7Dmmcz9Jl/5s88PTfVuj5gSRhv3daxY7lqPSaMaBnozwaODb62qyah0Kn8rVMlFQPl8OCfplXkydj"
    "X3wRM+3ElYv8lPM3g3+Gzh/wP6WNxVWltVVm5YYs+K9fsVokHrQbZo+cO9AuW5ofav6OEEzcUvmEP3JklbRm/e2Bfhb0MIQW"
    "nY1hhHGC06XkV+mKGbcHGJyTc8NjwsQZns7513C8VWfgy7uOGfKUiKNacb7CBtl+PltN9RLw+99BtvXzYxIJh71Zhz4UkvEf"
    "1WmKhwny232b6r6F6t1JY3zsL40xhgG5b3ge3gr29JLcSXalWCwXB7bzq/N88n1fnuGZgIho0A65CsOo3Md3j5bR63ty6uB7"
    "vKdlUuZZo7Mtdj3gFAQLrtmkm4bGifthwhLPAWt8p7p9y1W9W4YzQbHUssWKiLrGHmZye5Ee/KmYEVvQqGkRtNFWpsQCPp2l"
    "iiqNatQMCA54w7Ped7CsBWMw5ieq/utXx64+fpJMymQtIcVSvAsOqIoR0z0M9AE0GlVTNlua1tVzXV0T7weE6189X884535p"
    "ynn6d6d1slUH66GO19U0zguKfvAfkKdQe7Eu3n+vRcnJNkFS2v9uD8BfrrXlepyLpM9E0IzDTJFr7bJxg3YpYevO2faTJ2OP"
    "Pz7tGn/UrwHfNm86Z3ZZ0BuycunWmbNy1Nl+ovKt4B9f/vhjo85dqJ7S+GKw7JLbTkkXFz+3VaNu7ci33doKo5GI6+PY86yS"
    "YkXzPytm3B5YNHjqtn4ZXm1EHMXWfhHhOD8jt8vx61dqzUkhJs7wW/bpnXZPOd/5WLWso7bXLiYjCjGtH3dY1loapJw0m1A5"
    "oTw1JtTyTi5sBaEGFzelqm7Lcbl7GInvWLQY2/2ntYpD7EfJKlnQippTOTWtqvsBXwWwltqVZvlNPW3CqZyamafz8oM4j1pr"
    "v4bhdIOJ0EyUPNa1nbTxztjKbiqHcqg7XsY3N3ve+WAmZZkTy5rNlv8EpFATmjBVu/x0vl2g8GjCCUjgn9qsC3H5K4bDwBzu"
    "Yp7yfb/CYm8MEHhqu3DZdkzULYmgdgvDp38XUDyeje8/8WFZNPd8PTdPeCUkXP/aebryqLsl1QVnvz5pWbQbGB1V30wSJ6Nz"
    "86/Da3idj5dNj0ROv76y8rRgVS6hSvvZLGPdYpOHvv12IT7TgGSwVOdVJoqDJVRkFcbaiAIM9LftfIZsV0G6n5ZaGErDWGHp"
    "Yn+2+6hR/zx9d/RN0+adsmrk4CppYf2FS5dKPH6YvWLu0CcK/NUX5QWbzoNgeVXVW/7EqQsYvGhiu8J+eFVK4pHJvr4s04Dx"
    "RoJXScT1y8tfFGohHEZJxYyU/D2tr+8zlC0rLsXIe02BIU/AelLjjvBTdOSPmtqhX2J7iC9Ox1bhhK2pGRdi3MI3mS2rgeJ9"
    "8+uCQFOLhdTZagfbAwF/R9AP9xDs25vg/XaSvbQWOkdwpoOg1nIlygHZ9nPHndy5oTeVfMInvoj4avQpYB0gA0MDr/9IPxqU"
    "lKTfkfk+3ubaefH6zQxYTLEsZ7kPEBQJ03KEvSFWSOFqFPlvBP0W5o8iEpIqDEd4eN+01r6PUmCMOc7FfcK3uspXfVlVf6uq"
    "h1dSGWgB+5YrTlzjErc7XJ0k3uqu4JJdDPpbBVgSCyrH3iXzMx4XFoYY4xiuLD9Lx0ybKZlEuMNdnr4F/W4S9CXeF6tA/gX2"
    "Al28/17VxWG/uE0u+I7zSrTP4iCmyLUWtbLXpk2X41CI8hcwWk1xl6JhxtcValf2jrt6OEynrD+8TWQXg2Bca5pG/hbFsG7R"
    "ZTOnBTNjtry5dQz/uewUG713Zl7RseurjDozsP4JG58fOCkePzT9pbwnpcNIkdIWEuj9xCpz5Hj/7+XRbKa+rUfvFq3M9v+W"
    "1ZMQTvBF/lx4/PqVNTUnhVLEOgAU2y6j74+5bvohJ46I0exLaOG4rfMuhksv03DvOtDX/qshR6Z62QnSvuCImlMZn16v6w8w"
    "cFKO7a9ZZepujUvchjXsJEn26OUiRLx5Oi/fFfchVf9bYE4Dvj2MYT9n2wYzXVnkxV2+s+/sBsMZLqWUWt/3b8WYlr5JbTF1"
    "TyJoLqy03b4poEBtq0XpkHWIGce4Xi/M2C46lS1KVFBERDIJTTwVMZF/pUlPCuDEsRxiYD8wZUAZ8LNiivGtrgIaMfZDRb0Y"
    "sVd89T9Zx7p/NNDgsQS2jNlia6m1ZVK2VZHvyXZSrDMv9/iuoIrQkrlvYzMPO4ZDi0JMw3IR6BWRJDYKEt++/v4B/S4qAFH1"
    "zYHiNGkq7zfYxnl8vGx65MDTr9dWrL91HfF2Op5Yx/25/sUhA3GZiuVP8mWZV15+nFtWmuhWGGxx7Qjt0cv1tlhPUqnUkuOc"
    "yQ8b3z9HF1/5i1vf21snLttGLcbkftb7Q/9R6K45a5C7PgKmYjtlotWWzfDhKSkrm+zpbPlflIONG7wKfGqLW4E+SZFJd2U2"
    "zhs1hPQnV1jlvaa8of+EdSwfd0THfWehdO2ITyX5GNf6NSyyqU4FBGJsD/w9EQ67huXrDoS/P2rsAfh3ensppW5c4l6RP+hn"
    "KnxGBNRw+6s8uxmgp6DfmvUD+Og/nCxADCmk8OYKrfjuJJnUgPbO760134+3I/WjXVQAWvaqq6jSuMQtikxlahDsDablGGjL"
    "ImM4e6AMrN0Z6Pd36YHi0O79gxik2Skb1vBWr+52v711OyMowTdRvoqDqurngfOx9hBgGMbsi7GFBjMUzIG5b5/i4DCCEfcD"
    "2NEsM9YuteaQtzStjxLgP0uW4IlIU26Nd6lfRaQHrjAdy4/esIsWk/+pD8nmN36sv9+S4XP5IS577XzeP+ouuXPUVHXp4/j+"
    "jmb1dmFsEXaQSxPCaCy3OlY1j6veJ/DuP7E2rInE75IkKU4mpSrcai7EOgJ/ZAfwz7I3Bgc2/Awlf8vAgpvRLdIxW+3iAu+v"
    "g8/bkdUJMGVlkz19YfANuGu/63/868suOVWvr6y8Oji4uCWr3tm28otLgkUlv3pHX5a/Yji3+ZXCh0Mlv3q7spJgdXHMbw3+"
    "RUU1ouqJTcm3gdS1Lzb/MxrFtIB+DCilSgAK0qsOtsrnVM31hUesW7W4/Ni8+4ilW9vi+psLt31yeZ9Q146U5l8aNG4MUmcz"
    "Q7WFD7pkk4kMA/IgXSISeldVJbfw9wwVYBfW1QXw7/KMmMEMp0zKmjbqxrEGvixZcFu9rnHJjEhhJN0btt8O639Y1f8umK8b"
    "zNcO4qBRqvpRhIj0to7213R2G6F6q1NguN31HpHIDtq0qhYCh2PtrzHmyBzoLzSGr4jIx6rq8GmPLOmBohEj1rKP32IJeIds"
    "noatpUZrQuMYd7Lv+/+jju5nrDsCGGqwgzFmqDEMB7O/gS8R4EKsXT16tHlC03ofAf4tIs1dUfDf+bEOTofIoyH7+5bWf2z9"
    "ywCwzWjap+4rD7bc3fclksTOmKiBw/8ii+afr5c3ejwdMlw//1z9+MiZ8nyrk/z6VGJ3FK++Q8mBUHUSiQDhsO+M/IqzRV8I"
    "3Yzb9ALDTj8/UsKMygTBqljY6+LE2A78FSvrZg0twq4/H+H2wkmNKxMacSIkbH/Myv5MILVk8leXjpn7wMuO752vy7/2x6oN"
    "eMNTKakt3XaIjqon6fmDHws2bTo9mN5yvKr3n4ULL95uPIYPT8mkSdMzOveiKUYog+B34zG0hTjGgGKSUibXeZWVpwUDax/7"
    "McJG8ob9TXW1pIh5rd+5uCm/V7KyP5lz9xoWMTJ+UXP65V8fgbA3wlN1q/dNk0td6FrMOgPDgBAEDwPeZTef9NaheV93Te0d"
    "gH+3x7SMMgMwwBZdJmLGk2X7f6oesGRjX7D9lvIu73qqatKkH3VxjzOYQYMoui1GbEpSkl5vWX+7ck6SfruSb3srHDVaExrA"
    "AKeQwvyBDHQ9vGLgaqAsdzrtRuvzSmOTmVpYKCv/XwP9na3xHDuXNnPQE5EngCfaJXCefl+Ewwy2GBiLMQcYmIphKtbeWa/1"
    "URFZ2RH4V8UIlMQl/cZUfXCw5VQbzDamsPVNwW2NdA1sMeCl+SnIDYmwBiNJ+iX514oF+IoauUvmv36e/qwgn9sFrk+doYtL"
    "H5GFuZP8er2mot0F/XbKhAkpAV8Wrjqiatx+bzwNdlrNrJPvS9ejxdVJqZqwvQWow1TWrcBfMKr5eiWQR1HBLegW2RMSPrUb"
    "078Ty2xCPedAcZv0tQE3Qv0c/8NnLyk5/pnf1Oj6UC2lHkBtbalduPDi4Pij6t7Rl/knxv9R0yt7Pzn+2HWLKiuHZFk/MLw2"
    "ZbTi9oDdPO1i4BVT9ty/EEdj2SN2s8pBKsv2i9c9dahV/Yqqud49au3qxeWleanSVHqr+k1M4andAup9RXtbtufOPKLOBfyA"
    "emWEGIQGnjjwnLlNkO0Xg7EftyxnazksJxBkN0q8ft7T7yr4bx3rHvXHDGY442V88xrdNM4YTpCsc9/qFay7t0zKmsIa7jMD"
    "2zSm+SlSwZCEHjGW17LtNSf9gssOzIFHnzP9jY0bD6rT5uJmbS6u07qS3FXcpE2HNGnTBFU9OK3poz7DZ345ilE3FlL4mLX2"
    "fRf3JbJbEustvOb7ZprjOlM+naDfMjXaS9Zp2OZmEWszlaQ76962unzAqqqTu9zcFWi5XFcedBy5XBznZHGc8b7vX2uzc8Ji"
    "zI8GMOBZVT0qZ9HrcA6KUFffjLeza0uaTH0znudTJzlv4f4scdBkGIlG1aQb+fumJmYMymfioIFcWn68upGk+Mf3MKXD+lYg"
    "X12N9Ab0s88o1eOPTznjf7Bgc6Yx7zYMB40NPn9OSeTv6cJj7nG7r4zERF8ZUgSci+E2mdS4MkpM4n0I/FnHv56Df7eXzr6n"
    "LMDKvxzrnaU100PjUpu39nkL81f1JCN5CVSHBPz1J2+vXMWcksiv0jRc/GVjOME4gftJ1iqtQL84mZSysuu88vJj86DpAiOk"
    "nWDgKVXfLMkpGdtAf6fGnD3bahhDWkA/TMQdf+rzzVr+2UIczqCJDXVrh5YDJBJJ0yKdKrZKKuUzOYFg+H+0xIhJ9or2auHv"
    "z/4GYLAtvMhgPguIGm5Zw5IN/eFLUUONr6pus7H3AJssSIDC20XEIn0HpmHCDoItCg76TSHByiDBykIK381dlSFC1SFCVcD7"
    "AQLzDOZK4McGc5wxJgO8jrX/wGe6I3K060oiB1qmm6AvrYBL+19hkK6At+06QZCuPrOjeloUAZ/sTq0HeK0UgqCqBl3X/bUx"
    "TAYeI3vC3eex9k5VPSwXxdPuWldFVDq5yP4ERHdROuxIEksKc8zDbEwbbli9xT47tIAfF4xluqJSejyEe6CoDynIAle4uu/e"
    "o7Q0C1z19cXvgsxyHHu+VhxWMHpkkZay4yEtHfkVhCNJE5drLZl1VwMhnPw/q9o+Bf2OpGEPhUSnJWE9R0b/o5GCAX9AGMvK"
    "O86QsgebDl148ValaPm4b/sLFsx0g2XpChyZI+p/d/1Hhw4qKflVeiwzTTC4PjtWNn0myofYox+VyOl+tPX459oyiYqDrNXv"
    "WJGH5JjMR8teOyqUKs36RrQG/QXsOaWzwY3FkEgkaZLJpCkuTsqUUdMcgJL439OaODwf+94dBPk8xvyiqGjqRvClqipraXIN"
    "5hHgZ4BjxB6kqnnAnhfWtwsMAG29uTs7RnbbfVFTTPHWhTyWse4iFjVv1s2fdbNe2Vhr6z2TeWwiE5tTpEJhwjbcx56KVVSF"
    "SqTkMd/3fmGM8wUwx29u2nzIs6FnayJE+qQHkyR9FMnQfHWIwEAwJ+YQqx5YBlRa7CDAxZpGDKuAZsVfop5WBwKBp7eBiwZy"
    "I9uT+eYDdbl/O0Be3wN994qD5LUC0nQum1Qv6u3RkNlW/YOqhoDmVaw6dwQjmg3mTIwpttb+SlV/kEyyKRzGYcdDuQYNzsOx"
    "tuNWbDX1N1PY7JO/q0RBfDZ+cZhAZKYsfWuaRlfWc1AwxM3zzmFF/F55LHq8uszuXgeub0CII325JKurSzUWSznx+Nub0i+F"
    "bg+Ypqf8jf/5YUnkrTtqZtWFeL1ryuqE6VWilxYNIb35XOBWOaZpxZ5w7kh7rD+ZRLrShcNTKUE9WVNVumBE45wnsN5Fq8uP"
    "e6whsHmrLKilVPcd+A9H1TO8mn8L2vTXgcve+QbCA2sWVppFb9/q6esPFtO4IYIxl6SOK/VUU9JaXYkQthoNG5zAt7E04Abu"
    "U33QSVGVaW/VVeypjHTBpK0KUdWisVlmXwxJEl4k4rRa8zNEy93P4rx+DVZPp5GbF1aedN+4i2N+IpE0W4E/Rqz6lza21BjG"
    "YMwBpAkT5EFVdURkN53Qt6ccKds16I9LvC1wpQF81R8BJQDW2JvyJG9ha6HcDyUNkDHe9SGce4CiAYEBf45I5IStTmO9B34N"
    "EzZ5kvfBJt30vUI78JcY+x2DGQX2XTA/dcT5uMORVXVzQO33UsFswPIRhqNzoL93jxG7l4APwRzzYCSmJaOcXQJNOeES1963"
    "RXszJ5x92KcB+Km1dowx5hhjzKnA2ZGI3JxTwABoWrm1ojkbm/C3Ar+2r2EEHPAtaTW8D7Bh0a5ZvJGkpO89S/MOmyFvVJyn"
    "V+YHuVtC3DT3fP3k2Ltk/vHHqzt7dg/akqTPI4eiUc8s33zoO2MGv/O0Y/zzdNYXH2bE6MZSYqYzj/xoaczEy67zYin9ORCg"
    "KP8vqg2yp8Zf50z+nTavtrRUE2D2LnmlXucH/0JT89NDzevf2vvAV/66uJy8N0vvywC8Pe5WL03MLTkm85rOkbdR74z1b37h"
    "iRffvrU+EnF9TdlrUBZTeNgDZXKdl0gUO+SiJopJCnK6paJwLJv9H2O4V77kvb948Z/zUmO27e3LHn70dS4WP7OtW9/ajm7o"
    "s6OGNIVqB+bh74fKl4FzcMXSbC6XL/NHjT5jksltoN8C/OIr9wLXAgXW5UxH5K//9Ufzdgr6XYJ+DRM2D+q9hyruWAfH5kDN"
    "WuwgA6e0mGQFqVXVr3t4AcD6+H2+dp2s5VuANNZuxJhCA1+q07rPFVJYnbXO9gnr16hG3UEM2oDDJZlMZhZGLzbGiQARVb0J"
    "eFhE/h3VcjdGaShnZm5tou5taTbGfMS22Jtg7/xTejMcAVFVYy3BFrpvMAthn+Y+XP69AX8fcERklXreDODo3AO/oqqP5Jz9"
    "HMB+8U7J5KJ6ru+Bwi7TFkgGdkVYsMo595MuP17dRa/xxH5H8oVBefw0X/jVE6frmd94VFaHUSfZzU5LAuE+BP/q6lKdPHim"
    "c2C8cqO+EJyB2/wEef8+QyZVzKiZddIOrL+tvJlSs1JiLw7bG11zLsgtMrFpBRhQu0difzVJKe5i5w0nJaqerH31S28Ok9f+"
    "6dimc7Uy+reFS9dvN2bBhetF1XMyrxfcGGhqmjF4y7vHRCLu01ox8HPUbZiCMZfBxIxqhcTYFsInhK1q2DA3cCaiQQjeWVFx"
    "duDNMZM/FSfPxmIxicViuvjx0XvtP3hZRK2sEzTPEYb4SsDJI+03Mhjnk/3zlAKU8RZpNpj72TLwbjlx09Ly8mvcZG1SW4M+"
    "gCsivm7WvzCAazA4GFuizfoF4J3dy/p3P+jvDPrDhGUCCSCmLvnfNphrdvIQ4+D8CcAla7Fp+dlvZSsCmUAhBbeJSGlfevfH"
    "idsECUHJD0jgOeA5XzVusOeAudxiT/a85utW0fSiiKxrZdbvrfKhqmpEJK2qL+XWONbaYY7jqGpvzes9KRkVEavqD9/W8d58"
    "kYDXt3vfPTthseXLOWV+hbVsNIahWPs/njWfA1a2PNzaLGhXRjW4efM2579PPtmJAC9AWYKXDafbpblAtHYEOhysV8fNm6F4"
    "cD5TRgzg58ClE0DDYSSZ3L2nja4YOV7DYc/ZwKS3Buu/Z4F3ns4dnVhQPbp+Z6w/WhxxJ0X+ntZyvQzFNMjgO1XX9ZrtVyyY"
    "5I7Yb7WriUN8/OoADiCY8XU1QU0cYlKp+8yYrXenuvXslaFm2S/nDuePLNAlY872ailtt/9rKdUkmMgxr9fpvPz7STc84m3+"
    "7XHjT/VeXLx4c96bY7Zj/U7Jken5OodliH+GqjeLl91pGJasC419ZNikuzIJneyQy5cRAxBHm18bcFDI8y/AcLeUegsXl3+Q"
    "9yTbjklukezRWEzCxUl36Ph1AU0cIvC+m1tqzpG8FtTEIf7CZ8b1fm4fBOl0UJPFYa8zH43i4mIRcay+OCyEoz9jXzuWNWDT"
    "vOCINFnLQDF87KtZiJr1Du6dzgnp2Vn5sImaW04KvX17sdc2giSLPwBFbMbjrxjONZh9rWuvcsQ5TVWDu4f179Zowi5Bf5Kk"
    "RkmZuMS9S/XS+4ooygfUYMRCEfBlk01C1WCxTxrMSovdJS9mMAIELPZ7BjMMzBGqOnEmM9+ZxrQ+G8+c30BzQhNBwHdEohnN"
    "vGqsPdsY9wyc4KMjCT6o6fRMEZmbQ+1QzvzcFwi4HmgACjAcpKojgdU5tcd271E9LQkDD2UaGhr2tzDGZNGzCZP5IDd7pOem"
    "/j5dH1ZEbHOzrgkGWQQMxZhC12w972i7jiiOkclZaXLmxj1TeY8ksTOm4k6dydrXz+GazWnGDsrjJ6+eo+986V65N4E6gHSH"
    "+fcH658wIeYMOfHtTZnng3e5gea/k1kRmTTtrhmz2mH9WSDKtiH24l77ouunYtw/FpSuW97bQ9Nraupl2rR/58Z2OVrOx2TD"
    "mDbv+/VVDbCqzTxb1oNa3mg1nR4koZ6zM9aPwGZn9JsD5f0Fbqb5Ul181itVb46xjGnD+stfdMn7RpyGuvuYHTwD40/2jfvH"
    "VYWHNaku3Mr2AeLGsaqPOsz53jcQDeAMukMrvhtITmyf7cfj19p4Vi6lYQ0626zIjcra0ZHljbC8j2futaDtE8+VtSMFlpFl"
    "6WEjk53VOv8zh7Hso6sxeooR85yUclOb5Q2kKS+/xh1Dyl1CqfdQKpZhQvu1u9lFLWlV/Q3Y74ApMMYcmU6njxKR13b1oT3C"
    "tuQLe5Iu0B74xymzKGYv2WsR8H8tnzdp04QAoRMB12L/4ojz893R5mZtfiuIOwNMCOxN02RaaVSjbpx4n3rAR4h4YcJSruV5"
    "AQk8X6EV5ROZOB+YbuD7GOc49fQvONyfMysHe2nyb5kJjRa7wmA+Y6w5GMNXgAfIbbf0P+gDTHAg7AeD/jeMNWMwKLCShoY9"
    "MiwxGKSWrBT7IjCArJLaV52xW8q0mZLZ/2QNnXqv/GfOeXpF0Oe+QXnc8PK5uvSEe+SlKJ2HtOa8+rfuT/f9Vn+pTSRizibv"
    "iDeHum8+g3g/1BdGPZZyj9jUmvW3yJhwVcQtifw9rbPtpVg2NxYU3ZOvZLekeyEJV6z4mu+lFlzsFPFZ6vBRRgEhjE72X+Yv"
    "RrAI0qPJ26plJhuYXVc3YNwNRbAuRcppj/nXUqpqPRODDdfMdR5yrL2B5Y8dVRyuTwUXXhx8e9yt3lbWn445JSVb3tTZ5iU0"
    "cz3Ch6vyRiRLSv6eTmhyK9tvkRCb3/jJXgN97ywc7pFj6xbV1CwNVbU6HjkOhKmWpBir5boXwrkUMI4GPKx/cNYOwvc1pYeg"
    "vbeXWouaEOKn+bihsPCegWLWRvWXOzx1v9a4E4VSrnHlyOs2g/xUy2UZ2Kj/MucaE7pQSjPlNbecFGoYvML1Go9ML6ottqmq"
    "WKfEqrW9eTG++R0OvwZGBQKB36nqacBmVfV3ZSY/yYXza8s/+8/Ur10390M0tyzbKgBRjbpTmBKcyETTSOPgAIFrDIy1sHgL"
    "W+5TVVPFmoLNfLTLrCdBghKS0H2+elcaOAjL4WlNH1tDzevVVGtfZ/NLktQkyXSlVgZLpCQN3JpWfUOsN8113LOB31hrj9NM"
    "ZqaI/DPH/vNy7L/bbcmZrVcrOhP4PYZBYItFHNt5uGRfYlxQRMRX1c/lgFStsQ+ZgoZ1OfGi/bZKemD2T6fT+wSDwdFZjmDr"
    "DWZzt1StPVI9UDn1WdKJsAaPu1uefeUsvWmvAfxmcIA/zjtPv9X8IUvis7sc7rm1Q5NZ9M/FRvee9U+ZMs0Mm1SxWV8y9yL+"
    "A7hry8rKrnts8b3H5rGE9FbQL04K1aDlRWPwN52JBH5RcPj6T7a2rOUMhVjfCkdjAO1h7G8O9LsbkwuwYMFMJz5peuZHr4//"
    "18jG988zXtOPRNzymprp2903ePACF0gjspgiDrB18tyAYMDPJqVJtpLraHHiUWdg05nfsjDcmMG3amJyMDmuvYyJYbKRrru2"
    "1DcUCtRJdTIpozasFJjb4VpOEbMVM1YGJo4fqVJ23W1aXjDX0BiH5oc1Zf4UK3/mN/FLnOaliYL8J6tmdMmvyN1myhNfVW/H"
    "8g0MhwOHW2svdhznmpyAbtrVnbODAtAPrL/r4N+xAhAnbs/kCF9EGjKa+bLBnJqVIP4dG9n48SM84rzIi439kTq345ZGUVXj"
    "wf8aa2dhTJ5j9doSp6Rshs4IJEn2pRKy9b1KKMlEVc0UcIIi81fqynf38Ye/ieNcZIw5BWMmqe9/GZO5XUTeyzmVOXTPw1/J"
    "Oqs1qOq/cgOT71s9pVmbHwAqc3Pb61/Qr3BhXFpVJ1r8LxscHzAeTYmQjG5UjZr+A/7uy3VVtcBIiz3YZOnLWrLbJV3XIPbg"
    "I72qkniJsAYzDfylPsCRe4X4tm+55ejZ8lUNqyPJHnn5K9EcrLSJ8e+qMjBhQrbeRYsm20RisrO27prXhg38oBxJ/3DD4we8"
    "+NGag7cUFyeFnAPW9C1/DpScM7fJf9lebIT1dXXDnhIc1Zhv2givbisAo0Y95bilcuvW4SzXMcBJWHlRTpCL+njKAR+RUBw6"
    "2OcHWDRxqk3oVGdfWO/PCd6HZq7UNwaXpJZ/+/1Dudh9e9yt3nBSMmrU5WmtWDmIugXfYDNPG9Vxwea6QnA2wqPbVrg4qk/t"
    "NxCbucLCw86xm5ZWVhKsaue8jCRhRcMiYjYCN2/tl9nmBKz/ZSwPypfltr5V1gHWQBSTrArr5FEvdvrNJ1fM8BcNTkrNrJNC"
    "Uvb825r4TtgOe+waI/aXsTIzKfalIRfISW+sqJl1Sujt+nO9ts58bQMX3FYMSoBNGC4FHgeGYbjA8/Q9EXlYVUMi0rwrFnAO"
    "DFy2pSj1WjpN94i9/2ir/2dn+GZG2AZdt7+L+31goMXO2cCGB0fL6MYc0O7ShseJU021JCX5sqr/OnCcQb6YUT3xA6pmhwn3"
    "Joe/7rxuNA5ehWpgpMgW4HZVnZ/bSvoFxlwIgYnqeQ8lk8k7IpFIpgfs36qq2cjG1QMZeJfBXOIYp1iQS4ELctsI/bhBFBUY"
    "aIACi/25wflMrlk3B2lYnHXq6wz0yx34TAB8hXU+TPJ6Jky69IpWRNTzvOGO4xQA1mA+AFpCTG23Rn8PBP84aAL81AQaTlzJ"
    "Tzen+UxRkFPnna9RuUviibA6yWTPHkwUmLB9R3f7UVVhrZgyzRk+aWGdpoIPoOm78wd8ctykaXf9a9aspSEIZ8LFSSkde7Df"
    "WD7/ILT5DCRwVVHTLRtUwx1HnXVDARg/vlC14gsB0qtdPjnKRx8/APEEYeDK50oG7LPp4MyS4Wu6ZdReGWqW9szU/siQLhkT"
    "82q7MEHHMtOITPc3VY97fOCa98+mcePPysom/6BSrzYA+/IPB25N+/XVJzlGghvMXtMHZTY8VNC88Ts1NSf9ZRzhdDKZNMlw"
    "WFWvcUld9w2EQenM0Bsr9LRAkhlee1I8R95E1cKCSe4q95PgPjVDM9j3R+VuG7Y0sW/+/gz0FxamezTrl6/ed9v3xkBjY77e"
    "W3+ul6zavl+sIjvr+KqqsFYRzlQmIkGJ/D0Nco3ONW/h+7+07voXNBW4Wkqff1wT5zoTwhE3mUx41cW5uZHsmPFrLoxnnufp"
    "JY7DIwYzGIc/qSo58M8D0iLSb/uXrSIJ/J6ATv+z/va+X4rIpIznecfh8FWgwcO7e7gMX1GhFYEnedKPtvESiO8CQZgkqarq"
    "pOFC1/KKMabIxf6sREpemKWzQkmSnYa1uLgKMJ7xXfDI3/7Pk8ALqzoJEBH5d7nqO6X41eBcDuYoHA497bTwSap6s4jMzpnv"
    "A9ClXO8KmMEyeGOzNt/pWneKMeYAgznN99Mvum7o4R2Vib5Cq6jA2UGRA5s8zzvLcZxTyIZw1jSz6dYC2bs+qlET7wD4t1rN"
    "s8fmbhVIlZoIlkgk3ddZ8JJJTDgMqrq/tfYMtqUJnC0iq3K5FfxuYX03Tf+7ykUne5gP7jEL5KPXztOfNKR5sMDll/PO18VH"
    "3yUPHI/2LJwmTl+cRM3vFk225eUjXTY/NZuif88NuP6PNs4dPXfQynM3E4PpqT8HZNLcJk3Z6aisrQ8MeaoocrofDuMkJ4S1"
    "E0GUOwFzQvb41S1FQt4mQGn2ggIeRTUHS2zFDL+UmJbFr/P0JZPJjaddPvTI9Miv3JWJqt8t4K8mKR1bQUq79IxFTLWq411j"
    "Jq/LlAcecDRzmc7L+1wyGaueEI456aohKiWu6mz7Q+DlIcduWqop8yRip9jN/3lQxFmb0EdJimMFrJbb6ag8POCkDSsqKggw"
    "sdP5KTxZ4SeKI5lI5LG0luf82gR/PkelR0ce87sUQtnZUdZLug0uO67nWMIrL4+5tbXFKsee/g+dO7gCu/G32PTDmpLbpPSM"
    "nwL+vHmRfJqnZ6prS7VDU38r4DUi8qjnaZHjMBMYbC1/8jwVEXmoJU94X4f55SwOeSLSqKqTwF4KphDfT+Jc97BIvNO92xgx"
    "YttBqnajf3sG/lOY4sBEv0mbDhEr04F8a71Hgib4hKo6KVLa1lJAJzIk3oVPus4HxSK866smgXOx5osZzUxxcZ+NEjV95+jX"
    "fl8nckxSVQMikgEeVNU3PGvPcY35uTF83fr2s6r+C8DludPjWuL+tfNpoy7wAerHsfY+jBnoOO4NmUxTnYg8mXuWB71TVmXr"
    "+yTMoRzqjpcDm5o973RxnOuAAsDPkLkyn8GfJDThRIh0WJ9IyyE8ma+B+REYi+fdJRJ4WnXlALijsS+3CMJhjIhkVPVQY8xJ"
    "OXb/MfByr/c/9kD2P20B3oypGjhqpqTmn6c3qfBb1/DbeT/U9597oBfJ2eJdWLydKWFVYZ1A0imLv9WQeTnwgCvpmQPs8qMl"
    "cvrT8+bdnH8UX8noS68dDOnvYtxrnll+2zo0LMkO2Hx7TSntjsRw+1sj67qb5AJqRBUaBh7weNGmj06nqeEHkYj708rKY/KL"
    "i1MN6bm/PxLbuA9O6GalSRg0Zqbd+PF5n2lcdxTCk1WEVRWHOWd8DWUkZu/fVlR8PfDkxBn+zmy38dYgm2y7HAxVVRNazrHf"
    "NTN9v45Bv+Xz25MxnTA8JRUVfwnIpOlLtfyH52IemofvX6Uv2yMo3OsCOfwflYnEhCDDsW3B32wvkLJncKuquK7c6ftMBTCG"
    "wSLc6qv/eyA/5w8Q6quc8znhbUSkMZPJTLGWv4H5HvB1IAhxzSkb2hUBve3a9l9XcqL34Bx26qhTEbEh3MMxHAWssoaHRWTT"
    "AhaYFKluA050hyva7qddlECiqmZT44brrGUzhiJj5UIRyZzJEU5u2etYxmrPJX+XvuqpqslFidR8YEyUJk6ylnnGMePBXIC1"
    "z6nqWSLSnHXtINCFyi2gOM4jGJOLrDCjjAncpZ73g9z2lMKMbjG99mZLBRVuFVU6XsY3q6c/ch3nzwZGAOL7/oUhQk8kSVJF"
    "1U47JKpRQ1YbaQDzdeCbuO7dac/7scjILTDKyW4DdFctaV+0i0gmnU5PstbearP+FAa4E1iQy6/Qu6gdZU+Kvs2C/0z8RFgd"
    "O5A7FP6W5zDSCfCnMd9gIKaXAjze6upBKa4O++Xl17ifyFEvITLPtf5Unbvf4Oee+0pGyq7zkPQ0VNZukUHPRCKn++Fk0nQk"
    "G3pcSvumn3fO9ru3KbKIqbay8urgwMMWrsVxnsQwpemVgoOLiy9oFHFswGv6X4xULDOHzV+g01w5bNlGg1S4fiby3txxRXFx"
    "rMjpPur/HJWEHLemtm7iyO7NzAm7YHLGtl3RGEyc2IV+TiKtL4Dq2lL93aKpNpG4OihlDzbJ8fonCgq/hVG19Rue8crlx5HI"
    "r9KkSm14QszpEPhbgT+twP8Ma1lvDEMM5lKsfTJ3uldzC5Pr6QlwOetBUES8FSsI+b5e77ruXcYwFsCz9kYc55GcVNkeQG33"
    "qtwR8ttXAroD/lOY4pRS6jdp03iQ6dn4efuAi/uiqoYWsajPtkQ6XuydKwSC6JCCIR8bwzWAGON8MaOZ08ZxilfeLYBpK+m1"
    "J1/0VdUtEUlLvrxgDGFruQlVMOZ44A/q+w/Xa/0IEUmzzdejs8b4wB99n59nlVUzApFbfd+/NausTstATTAbd9/VObKN5Ssa"
    "nCSTMjFiRar+DMTeZGAIgO9zgeu6M8lmcrRxiVsE3XrtgBtxRREXd3bG96/Ifby3I/J7Vf01TA1mtwF0p+3tpDgtoK+qhznG"
    "PG6MGWNAsPYBoMVhqe8sd3uWAqBVSfToP0ijDXBpk+XfoQBfLBnBzWK3nvGwtaxv6KEy0AMFIDIhrLW11ebAsrlNXiZwP3CE"
    "l1l+dIyYbU45n8MQAfe2G16uXR0OP+okc45a0b7olYnQVxlquwb6rcG/9dWRVgSIq4TynwaVkK0/U+R0v+mVAQcj+plmNS+N"
    "PvqNxneXfOCE9VGHYQN+BXrcZ2X5vqq+6MtyGvBZvAOvLS+/xu0sJXKf9Ws3wL5r9fo7AH3HPRvzp864PUDCc+TIhvkEJ3wb"
    "dR5y8G7xy7k/dsykokjJr9JhtoG/ad8UuR34P+r7fANrXwNcjCnF2r+p+vcAQ0Ukk81atvWoUNOeIqCqkvub03q7IJdD4LRR"
    "oyg3hivIMqi0j3/NJ8ZcIyKNgtCX4YQdKwHd0NoplolM9EREXdyvKXI4UAV+UkSaqqjSzphfb5WAzu9SzV1kPTd50GIXA3sZ"
    "a84REX9f9u0i8Jf2pWT3W+aCiKxYupSr8eUEssfHDsaYMwptwSue513aMr/YyRGyrQzO6jjcCEwFGjBmL2C6tfZFzejXRMY3"
    "i0R8qAxkGXXCgErb0c8BvShqKqhwIxLxRaRZPe90a3kFzHkYU4S1zcC5jsNfWhIGtjtPO1ACRMQPOM4fMvgXW0vaGFNINh9E"
    "eZM2nSIizSIRfwEV7rb2dqgImNzVAvieiGTU8y4HnjaOsx+AtfafbNhwkYjU73SP5r9AAYiDRqNqjvizrGvIcKHns06EHzjC"
    "t6zdPilRqzj+jq4+tQJUhRNeTc1JIXfw2c9ZkScN/nSJO9Z43g9R1q2j6Nl43LF9fW5AX5cwPQ11TLZ7VVPs18w6McThmz9E"
    "zP1YPW3p0sPzjb9lCkq63h30GsCYMaXeOQvvceVzDe9ZeB9vyxkijmL8K7DylJy4ZFPL6Xt9J1N7APLtgH37dW2bjGvWDuu2"
    "Erph8FQbBmbMuD0gR3+w3pzgXQWBs4z4XyKw4FWdE/hSJPKr9OQNM82EqpR0aP5scfYDCAblFVX9Gr4/FceJYsz+wFnAser7"
    "72LMHSLyfBugN63fJucTsHUBLdflBRnf/4XBHAMcBgzKCiZSxnCtgzPnwOyWgnQK+taIqjoLWGBKdxI20l5JtWP1ihFjAQt2"
    "2vlDGeoA6WZtLhHrXJZ1x/STEHhrsS7Ou4/70v296KJt5E6rN9D2FK+9RDZkNHOhwTxtMEd56n3XwUmWZ7ObdVAC/dX8lm0l"
    "R0SagHJV/RrwI6y9FmMOcuDXvq/fNB4Xi8h/WvLJdzQLstNMfOBOVX0Ha282xhwNHAnc7fv+ezZjfycSeGZ703u5W7pVvSm1"
    "bfxXfNXM1611r8TYCaYl4Y21b2DM/4nInJb+7ZJyKujWk9UUERGL6p/SfmYBODcaY44Cvhgi8Fff96uN0Rki7kPbj2XUQGnb"
    "bTqvzXj/2FrOBvt5cicXWuwtxphrYkNv25LQhBPLsiHpqqWr29v5E3Y/MMXjaBQ1pffIa/PP14sceBA4xiqW7h0/3nW5Es+N"
    "9E6QJB6D4uIiHR+5K6Op0D2Ypnv1Zc606NH45s6hX163PJxI9g3b31kolIPiZc2CQ+s+cDTxqF2wYJrZmcEAoCpvQ+cH8RRP"
    "sLUUd9pvO/D/U4p0vDi2aX7BE6Gm+sj+H77xY8Qe5mOeGXrUuhWJykjwdor9cLpaAYxrHsCzV+tsMw9lLH7hWdHo5h5Zyibs"
    "qE7LEUe87mjiUZ25oZ1+ac9Mv4Cd3rZo4mRbRVhbmHwxI7tvbepA23qRqXbqRAIieGj6UV0w6lW2rLoFaXreS5lfu6XTryfq"
    "mZ3ue7YWZCKyXlV/3wx/D1h+BvaHxpiDMOYgYLKvuhRYaGCe77NeRO5u/axm1S8E4QvWchgwHuwEY8yInCkXa3klneba+nrm"
    "Dx8udV0QptpK5Hvi7DQSoD9KJtfGL2PYF0jV0/iXIinyK7TC7GoBl3VS6Vx4b8J9ZbDlNWM4yrHyXXHkb4tVg+t234FMNqck"
    "am6O3dSUTj8WDAYeNMY50hiOw7XP+eo/ISLTWu7tePdITc5C8AbGnAycjbW/xpgRBjPChMxE9f2PreE/vu+/HXAC74nIU/Ht"
    "H/INH/8QsXIkmHHAAcYwAAxYuwmjN2Kc20RkU7dAvzX454A/qlETF7FBmLd2rZ48cKj/vQASA7O3MRwLTPJ9jWLsh77vzws4"
    "gbWw6q9ZX4Dt2nymxX4Wa75gDJ8BxhhDKIdt7wMxg3lcRNLlWu629T1p69ga68uz3g27tcRz8+XIu3j09fPsl/IC5oK0v1WB"
    "7C+HLd2qjesOzEIAIlUJr7y8NI/y1Ou21DxtHHuvsTK3KVD0dL44Gk482rsWDATSCIIj0oE/luYsaUr6wBPmNmUTyfSVLPg7"
    "CX3U6RTod/h72K/RulCIZ97zZzv3OQF7E57MbgzmP1skjkYrT8veVxz2Z9XUhVh+xN/Q+OWI/zCOPC4nbanBItHejW2Lct58"
    "6qnPN8PzfdAvLc25m3Ai7HRZQeumSWXDxKk2Wp5y4pRambRmqc77zvds+rFfONZe4c/haLPX53/QZYennHCzwEJVnQ7mZ8D/"
    "WjjXwFiT3Z0pBqY4DjZ3QlvrEgQCxrREEhiwdr01/NNgfm8MS/PzpbEjxaNdXbVFrrh8R1VP3cXyJIO1y6xlhDF4Pv7fiqRo"
    "TY3WhB7ioV16+lOLkI51IsmiqmaYyOampqbzQqFQNXCcp96ZLjy8NMsKM232PYRd47PdsrVkcsz1I1U9wff9yx2RyzBmbwNT"
    "1fePFJH/0fJyl9JSfyfgL7n5U6eqd2DMfT7+WViZ7hhzCMYUGyg2jvkuWafDtsmp8gQJGGO2Qpa1LDLq343j3AFsbB3S2ptt"
    "qJb9foBhIptRZmxgw6NFFH1LrJxjjPmiMYwDM8445itZy8Y+v88l42ldCgy42zmuWftWRvXegOPckyLVXCZlXkITTlccTlsU"
    "gb5QAKTVkdAiu0sNUAFRx9GfNlv+J2A4xsv2wicAe6/ux82JtkkWW3no18w82C+LOzZ9bN7fjDSObrTOHwrK6hZHo9e48apw"
    "j3yEamPFShwGBYO+TctCY3VZWgeshUbq6kZqLEvHVSvOD7DonQUMn99ASM/TlJ7RopB2+j66U4tWdk4bN7Zw4T1/Gn/w881h"
    "+2i3fInerirS8SWONr+aN8fxGh7HyD8Lj66vimrMraZ469pfNm60lfHXeTrbJPDtxHXBz1yGXdhj0G9qGpx9M2OWo3YtQXud"
    "priqS/3SmdWlxdqnwbPky+4/ouUvutt52wsBPFbXfW6o7e1srC4t1TDIBH3RFTO5MWpt7OpX8ua6fvMNrHv3uV4J9Rz7coFB"
    "Pv6ZgnOcgWJrKTKGkdvzOrvRYtZi7BKgwqPhkSCF75NNLNJtr+ItumXfPFuQMoaDdhORaLTW/gvMMIytmsOcy2upVYD+2tvf"
    "Geh3JGvaWAUkLmJXqxYO8ewMY8yxaoi7IncvVs07UKSpSXVcAPtngzkRuH8TXLaXyPqoqon30JuvR7Iyt9XURNOYPBucgTEn"
    "Yu0b4jhHdGLyb9dqpRo1VYTdYQwbPJzhFxg4GsxorB2e8wVoPVc3WEwtxi4x1qvApB+GwoVkk0n1bQ6LtsKklTVAUWcpS4v2"
    "8ff5lhHzFRe3xEKeMRxAW58Ha1dbTD3Gvqe+vp520g8sYtGqaqr9iER8FIkSld7Ote48IJHERCLiv3GZ7i91xIETm4UrvjST"
    "hIgoVmXXhwKKlp+lexUGeUKFvRTuP2Km3DxjogamLaD/zyTRdjtWAGaMmuZMmzbDY1tOfrpt5o+1+bUq4lZVT6CaWLuKclUV"
    "OnXilLzgkPWOm9myc3DebpVs7LQp7w0d2fyH/S/r1ZZnGKAq6SSLw36SsIZbORS2LpMXvGgG522QSHEiEyZpJhDulQwuJilH"
    "vnZzMN9ucJ28TJeV1U11RZ3O6Pcaj2u8t/5Wr+2LTl9ydiDkNMgf9k/0+TZxMicv570WyRs8eLn7/wF6gdXfjnKTQgAAAABJ"
    "RU5ErkJggg=="
)

LABEL_WORDS = ("label", "labels", "seg", "segment", "segmentation",
               "mask", "pred", "prediction", "annot", "annotation", "gt")

# 2D window/level(0-255 정규화) + 3D transfer function preset
PRESETS = {
    "Vessel": dict(ww=250, wl=120, lo=0.62, hi=0.95, opacity=0.60),
    "Bone":   dict(ww=210, wl=150, lo=0.55, hi=0.90, opacity=0.72),
    "Hemo":   dict(ww=105, wl=58,  lo=0.16, hi=0.45, opacity=0.38),
    "Full":   dict(ww=255, wl=128, lo=0.10, hi=0.98, opacity=0.30),
}

PLANES = ("axial", "coronal", "sagittal")
PLANE_TITLE = {"axial": "Axial", "coronal": "Coronal", "sagittal": "Sagittal"}

OPP = {"L": "R", "R": "L", "A": "P", "P": "A", "S": "I", "I": "S"}
CODE_RAS = ["R", "A", "S"]
CODE_LPS = ["L", "P", "S"]


# ===========================================================================
# 방향(orientation) 유틸
# ===========================================================================
def codes_from_matrix(mat):
    """index -> RAS 4x4 행렬에서, 각 voxel 축의 '+' 끝이 향하는 해부학 문자."""
    out = []
    used = set()
    for a in range(3):
        col = [mat.GetElement(r, a) for r in range(3)]
        order = sorted(range(3), key=lambda r: -abs(col[r]))
        k = next((r for r in order if r not in used), order[0])
        used.add(k)
        pos = col[k] >= 0
        out.append(("RL", "AP", "SI")[k][0 if pos else 1])
    return out


def dir_for(codes, letter):
    """해당 해부학 방향을 가리키는 단위 벡터(이미지 축 공간)와 (축, 부호)."""
    for a, c in enumerate(codes):
        if c == letter:
            v = [0.0, 0.0, 0.0]; v[a] = 1.0
            return v, a, +1
        if OPP[c] == letter:
            v = [0.0, 0.0, 0.0]; v[a] = -1.0
            return v, a, -1
    v = [0.0, 0.0, 0.0]; v[2] = 1.0
    return v, 2, +1


def plane_axis(codes, plane):
    """평면 이름 -> 잘라내는 voxel 축 index."""
    want = {"axial": "SI", "coronal": "AP", "sagittal": "LR"}[plane]
    for a, c in enumerate(codes):
        if c in want:
            return a
    return {"axial": 2, "coronal": 1, "sagittal": 0}[plane]


def vec_to_letter(codes, v):
    """벡터가 향하는 해부학 문자."""
    a = int(np.argmax(np.abs(v)))
    return codes[a] if v[a] >= 0 else OPP[codes[a]]


def cross(a, b):
    return [a[1] * b[2] - a[2] * b[1],
            a[2] * b[0] - a[0] * b[2],
            a[0] * b[1] - a[1] * b[0]]


# ===========================================================================
# 데이터
# ===========================================================================
class Study:
    """원본 볼륨 + (선택) annotation 한 쌍."""

    def __init__(self, name, image, label=None, codes=None,
                 modality="—", source=""):
        self.name = name
        self.image = image                  # vtkImageData
        self.label = label                  # vtkImageData(labelmap) or None
        self.codes = list(codes or CODE_RAS)
        self.modality = modality
        self.source = source
        self.label_source = ""       # annotation 파일 경로 (F12 저장 위치 결정에 쓴다)
        self._ids_cache = None
        self.truncated = False

    @property
    def dims(self):
        return self.image.GetDimensions()

    @property
    def spacing(self):
        return self.image.GetSpacing()

    @property
    def origin(self):
        return self.image.GetOrigin()

    @property
    def scalar_range(self):
        return self.image.GetScalarRange()

    def label_ids(self):
        """labelmap 안에 실제로 존재하는 모든 클래스 id (0 제외)."""
        if self.label is None:
            return []
        if self._ids_cache is None:
            arr = numpy_support.vtk_to_numpy(self.label.GetPointData().GetScalars())
            present = [int(v) for v in np.unique(arr) if v > 0]
            self.truncated = len(present) > MAX_LABELS
            self._ids_cache = present[:MAX_LABELS]
        return self._ids_cache

    def invalidate_labels(self):
        self._ids_cache = None
        self.truncated = False

    def voxel_to_world(self, ijk):
        sp, org = self.spacing, self.origin
        return [org[a] + ijk[a] * sp[a] for a in range(3)]


def numpy_to_image(arr, spacing=(1.0, 1.0, 1.0)):
    """arr shape (nz, ny, nx) -> vtkImageData."""
    arr = np.ascontiguousarray(arr)
    nz, ny, nx = arr.shape
    img = vtk.vtkImageData()
    img.SetDimensions(nx, ny, nz)
    img.SetSpacing(*spacing)
    img.SetOrigin(0.0, 0.0, 0.0)
    va = numpy_support.numpy_to_vtk(arr.ravel(order="C"), deep=True)
    va.SetName("scalars")
    img.GetPointData().SetScalars(va)
    return img


def _first_component(img):
    """multi-component(4D/RGB) 볼륨이면 첫 성분만 남긴다."""
    if img.GetPointData().GetScalars().GetNumberOfComponents() <= 1:
        return img
    ex = vtk.vtkImageExtractComponents()
    ex.SetInputData(img)
    ex.SetComponents(0)
    ex.Update()
    out = vtk.vtkImageData()
    out.DeepCopy(ex.GetOutput())
    return out


def read_volume(path):
    """파일/폴더 -> (vtkImageData, codes). NIfTI · NRRD · DICOM 폴더."""
    if os.path.isdir(path):
        reader = vtk.vtkDICOMImageReader()
        reader.SetDirectoryName(path)
        reader.Update()
        img = reader.GetOutput()
        if img is None or img.GetNumberOfPoints() == 0:
            raise IOError("DICOM 시리즈를 읽지 못했습니다: %s" % path)
        out = vtk.vtkImageData(); out.DeepCopy(img)
        return _first_component(out), list(CODE_LPS)

    low = path.lower()
    if low.endswith((".nrrd", ".nhdr")):
        reader = vtk.vtkNrrdReader()
        codes = list(CODE_LPS)          # Slicer 계열 NRRD 는 보통 LPS
    elif low.endswith((".nii", ".nii.gz", ".hdr", ".img")):
        reader = vtk.vtkNIFTIImageReader()
        codes = None
    else:
        raise ValueError("지원하지 않는 확장자입니다: %s" % os.path.basename(path))

    if hasattr(reader, "CanReadFile") and not reader.CanReadFile(path):
        raise IOError("파일을 읽을 수 없습니다: %s" % os.path.basename(path))
    reader.SetFileName(path)
    reader.Update()
    img = reader.GetOutput()
    if img is None or img.GetNumberOfPoints() == 0:
        raise IOError("빈 볼륨입니다: %s" % os.path.basename(path))

    if codes is None:                    # NIfTI: sform/qform 에서 방향 결정
        mat = None
        if hasattr(reader, "GetSFormMatrix"):
            mat = reader.GetSFormMatrix()
        if mat is None and hasattr(reader, "GetQFormMatrix"):
            mat = reader.GetQFormMatrix()
        codes = codes_from_matrix(mat) if mat is not None else list(CODE_RAS)

    out = vtk.vtkImageData(); out.DeepCopy(img)
    return _first_component(out), codes


def cast_to_labelmap(img):
    """label 볼륨을 정수형으로 정규화."""
    cast = vtk.vtkImageCast()
    cast.SetInputData(img)
    cast.SetOutputScalarTypeToUnsignedShort()
    cast.ClampOverflowOn()
    cast.Update()
    out = vtk.vtkImageData(); out.DeepCopy(cast.GetOutput())
    return out


# ---------------------------------------------------------------------------
# 데모 팬텀 — 실제 데이터가 없을 때 UI/렌더링 확인용
# 좌표계: RAS (+x = Right, +y = Anterior, +z = Superior).
# A/S 를 고정하면 오른손 좌표계에서 +x 는 반드시 Right 이다 (R = A × S).
# ---------------------------------------------------------------------------
def make_phantom(seed=11, modality="MRA", site="AComm"):
    nx, ny, nz = 128, 152, 128
    rng = np.random.default_rng(seed)
    bone = modality == "CTA"

    z, y, x = np.ogrid[0:nz, 0:ny, 0:nx]
    cx, cy, cz = nx / 2, ny / 2 + 2, nz / 2 + 4
    q = np.sqrt(((x - cx) / 52.0) ** 2 + ((y - cy) / 66.0) ** 2 + ((z - cz) / 56.0) ** 2)

    noise = rng.random((nz, ny, nx)).astype(np.float32)
    vol = (2 + rng.random((nz, ny, nx)) * 4).astype(np.float32)
    vol = np.where(q < 0.86, (46 if bone else 52) + noise * 10, vol)
    vol = np.where((q >= 0.86) & (q < 0.94),
                   (210 + noise * 30) if bone else (26 + noise * 10), vol)
    vol = np.where((q >= 0.94) & (q < 1.00),
                   (235 + noise * 18) if bone else (20 + noise * 8), vol)
    vol = np.where((q >= 1.00) & (q < 1.045),
                   (96 + noise * 14) if bone else (70 + noise * 16), vol)
    vq = (((np.abs(x - cx) - 7) / 6.0) ** 2 + ((y - cy + 6) / 16.0) ** 2
          + ((z - cz - 2) / 14.0) ** 2)
    vol = np.where(vq < 1.0, 22.0 if bone else 16.0, vol)

    lab = np.zeros((nz, ny, nx), np.uint8)

    def m(v):                     # 좌우 대칭 (RAS: x < nx/2 = Left, x > nx/2 = Right)
        return nx - v

    tubes = [
        (48, 60, 16, 50, 66, 52, 2.6, 2.3), (48, 66, 52, 52, 74, 66, 2.3, 2.0),
        (m(48), 60, 16, m(50), 66, 52, 2.6, 2.3),
        (m(48), 66, 52, m(52), 74, 66, 2.3, 2.0),
        (64, 56, 14, 64, 62, 58, 2.4, 2.1),
        (64, 62, 58, 58, 64, 62, 1.7, 1.5), (58, 64, 62, 50, 60, 60, 1.5, 1.2),
        (64, 62, 58, m(58), 64, 62, 1.7, 1.5),
        (m(58), 64, 62, m(50), 60, 60, 1.5, 1.2),
        (52, 74, 66, 58, 84, 72, 1.6, 1.4), (58, 84, 72, 62, 94, 80, 1.4, 1.2),
        (62, 94, 80, 63, 102, 90, 1.2, 1.0),
        (m(52), 74, 66, m(58), 84, 72, 1.6, 1.4),
        (m(58), 84, 72, m(62), 94, 80, 1.4, 1.2),
        (m(62), 94, 80, m(63), 102, 90, 1.2, 1.0),
        (58, 84, 72, m(58), 84, 72, 1.0, 1.0),
        (52, 74, 66, 42, 76, 68, 2.0, 1.7), (42, 76, 68, 33, 80, 64, 1.7, 1.4),
        (33, 80, 64, 26, 82, 58, 1.4, 1.0),
        (m(52), 74, 66, m(42), 76, 68, 2.0, 1.7),
        (m(42), 76, 68, m(33), 80, 64, 1.7, 1.4),
        (m(33), 80, 64, m(26), 82, 58, 1.4, 1.0),
        (52, 74, 66, 56, 66, 63, 1.0, 1.0), (m(52), 74, 66, m(56), 66, 63, 1.0, 1.0),
    ]
    bright = 248.0 if bone else 236.0

    for ax, ay, az, bx, by, bz, r0, r1 in tubes:
        rmax = max(r0, r1) + 1.5
        x0, x1 = int(max(0, min(ax, bx) - rmax)), int(min(nx - 1, max(ax, bx) + rmax))
        y0, y1 = int(max(0, min(ay, by) - rmax)), int(min(ny - 1, max(ay, by) + rmax))
        z0, z1 = int(max(0, min(az, bz) - rmax)), int(min(nz - 1, max(az, bz) + rmax))
        zz, yy, xx = np.ogrid[z0:z1 + 1, y0:y1 + 1, x0:x1 + 1]
        dx, dy, dz = bx - ax, by - ay, bz - az
        l2 = float(dx * dx + dy * dy + dz * dz) or 1.0
        t = np.clip(((xx - ax) * dx + (yy - ay) * dy + (zz - az) * dz) / l2, 0.0, 1.0)
        d = np.sqrt((xx - ax - dx * t) ** 2 + (yy - ay - dy * t) ** 2
                    + (zz - az - dz * t) ** 2)
        r = r0 + (r1 - r0) * t
        sub_v = vol[z0:z1 + 1, y0:y1 + 1, x0:x1 + 1]
        sub_l = lab[z0:z1 + 1, y0:y1 + 1, x0:x1 + 1]
        core = d <= r
        np.maximum(sub_v, np.where(core, bright, 0.0), out=sub_v)
        sub_l[core] = 1
        halo = (~core) & (d < r + 1.0)
        np.maximum(sub_v, np.where(halo, 60 + (1 - (d - r)) * 150, 0.0), out=sub_v)

    sites = {"AComm": (64, 86, 74, 5.4), "MCA bif": (42, 76, 68, 4.8),
             "ICA siphon": (51, 70, 60, 4.4), "PComm": (55, 69, 64, 4.1)}
    sx, sy, sz, sr = sites.get(site, sites["AComm"])
    sac = np.sqrt((x - sx) ** 2 + (y - sy) ** 2 + (z - sz) ** 2) <= sr
    vol = np.where(sac, bright, vol)
    lab[sac] = 2                                   # Segment_2 : aneurysm sac

    # Segment_3 : infundibulum — PComm 기시부의 원뿔 모양 팽대
    ix, iy, iz = 56, 66, 63
    d3 = np.sqrt(((x - ix) / 3.0) ** 2 + ((y - iy) / 3.0) ** 2 + ((z - iz) / 2.0) ** 2)
    inf = (d3 <= 1.0) & (lab == 0)
    vol = np.where(inf, bright, vol)
    lab[inf] = 3

    # Segment_4 : superior sagittal sinus — 정중선을 따라가는 정맥동
    d4 = np.sqrt(((x - 64) / 3.2) ** 2 + ((z - (0.55 * y + 46)) / 3.6) ** 2)
    sss = (d4 <= 1.0) & (y > 40) & (y < 120) & (lab == 0)
    vol = np.where(sss, bright * 0.82, vol)
    lab[sss] = 4

    # Segment_5 : ICA 석회화 플라크
    d5 = np.sqrt((x - 50) ** 2 + (y - 66) ** 2 + (z - 48) ** 2)
    plq = (d5 <= 2.6) & (lab == 0)
    vol = np.where(plq, 255.0, vol)
    lab[plq] = 5

    name = "%s_%s" % ("CTan" if bone else "MRan", site.replace(" ", ""))
    return Study(name, numpy_to_image(vol.astype(np.uint8)), numpy_to_image(lab),
                 codes=list(CODE_RAS), modality=modality,
                 source="synthetic phantom (%s)" % site)


# ===========================================================================
# 2D slice pane
# ===========================================================================
class SliceStyle(vtk.vtkInteractorStyleImage):
    """활성 tool 에 따라 좌클릭 동작(crosshair / pan / window-level)을 바꾼다."""

    def __init__(self, pane):
        super().__init__()
        self.pane = pane
        self._drag = False
        self.AddObserver("LeftButtonPressEvent", self._down)
        self.AddObserver("LeftButtonReleaseEvent", self._up)
        self.AddObserver("MouseMoveEvent", self._move)
        self.AddObserver("MouseWheelForwardEvent", lambda o, e: self.pane.step(+1))
        self.AddObserver("MouseWheelBackwardEvent", lambda o, e: self.pane.step(-1))

    def _down(self, obj, evt):
        self._drag = True
        tool = self.pane.app.tool
        if tool == "pan":
            self.StartPan()
        elif tool == "wl":
            self.StartWindowLevel()
        else:
            self.pane.pick_here()

    def _up(self, obj, evt):
        was = self.pane.app.tool
        self._drag = False
        self.EndPan()
        self.EndWindowLevel()
        if was == "wl":
            self.pane.app.sync_window_level_from(self.pane)

    def _move(self, obj, evt):
        tool = self.pane.app.tool
        if self._drag and tool == "cross":
            self.pane.pick_here()
            return
        if not self._drag:
            self.pane.hover_here()
        self.OnMouseMove()
        if self._drag and tool == "wl":
            self.pane.app.sync_window_level_from(self.pane)


class SlicePane(QtWidgets.QFrame):
    """한 방향의 단면 + label overlay + slice slider."""

    def __init__(self, app, plane):
        super().__init__()
        self.app = app
        self.plane = plane
        self.orientation = {"axial": 2, "coronal": 1, "sagittal": 0}[plane]
        self.slice_index = 0
        self.setObjectName("pane")

        self.widget = QVTKRenderWindowInteractor(self)
        self.slider = QtWidgets.QSlider(QtCore.Qt.Horizontal)
        self.slider.setObjectName("slice")
        self.slider.setRange(0, 1)
        self.slider.valueChanged.connect(self._slider_moved)

        lay = QtWidgets.QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)
        lay.addWidget(self.widget, 1)
        lay.addWidget(self.slider)

        self.ren = vtk.vtkRenderer()
        self.ren.SetBackground(*C_VIEW_BG)
        self.widget.GetRenderWindow().AddRenderer(self.ren)
        self.iren = self.widget.GetRenderWindow().GetInteractor()
        self.style = SliceStyle(self)
        self.iren.SetInteractorStyle(self.style)

        self.img_mapper = vtk.vtkImageSliceMapper()
        self.img_actor = vtk.vtkImageSlice()
        self.img_actor.SetMapper(self.img_mapper)

        self.lab_mapper = vtk.vtkImageSliceMapper()
        self.lab_actor = vtk.vtkImageSlice()
        self.lab_actor.SetMapper(self.lab_mapper)
        self.lab_actor.GetProperty().SetInterpolationTypeToNearest()

        self.corner = vtk.vtkCornerAnnotation()
        self.corner.SetMaximumFontSize(13)
        self.corner.GetTextProperty().SetColor(0.56, 0.65, 0.78)
        self.corner.GetTextProperty().SetFontFamilyToCourier()
        self.ren.AddViewProp(self.corner)

        # 상/하/좌/우 방향 문자
        self.edge_text = {}
        for key, (px, py, halign, valign) in {
            "top": (0.5, 0.975, 1, 2), "bottom": (0.5, 0.012, 1, 0),
            "left": (0.012, 0.5, 0, 1), "right": (0.988, 0.5, 2, 1),
        }.items():
            t = vtk.vtkTextActor()
            t.GetPositionCoordinate().SetCoordinateSystemToNormalizedViewport()
            t.SetPosition(px, py)
            tp = t.GetTextProperty()
            tp.SetColor(0.49, 0.59, 0.73)
            tp.SetFontFamilyToCourier()
            tp.SetFontSize(13)
            tp.SetJustification(halign)
            tp.SetVerticalJustification(valign)
            self.ren.AddViewProp(t)
            self.edge_text[key] = t

        self.cross = vtk.vtkActor2D()
        self._make_crosshair()

        self.picker = vtk.vtkCellPicker()
        self.picker.SetTolerance(0.005)

    # -- crosshair ---------------------------------------------------------
    def _make_crosshair(self):
        self.cross_pts = vtk.vtkPoints()
        self.cross_pts.SetNumberOfPoints(4)
        for i in range(4):
            self.cross_pts.SetPoint(i, 0, 0, 0)
        lines = vtk.vtkCellArray()
        for a, b in ((0, 1), (2, 3)):
            lines.InsertNextCell(2)
            lines.InsertCellPoint(a)
            lines.InsertCellPoint(b)
        pd = vtk.vtkPolyData()
        pd.SetPoints(self.cross_pts)
        pd.SetLines(lines)
        coord = vtk.vtkCoordinate()
        coord.SetCoordinateSystemToWorld()
        mapper = vtk.vtkPolyDataMapper2D()
        mapper.SetInputData(pd)
        mapper.SetTransformCoordinate(coord)
        self.cross.SetMapper(mapper)
        self.cross.GetProperty().SetColor(1.0, 0.75, 0.0)
        self.cross.GetProperty().SetOpacity(0.6)
        self.ren.AddViewProp(self.cross)

    def update_crosshair(self):
        st = self.app.study
        if st is None:
            return
        self.cross.SetVisibility(self.app.show_crosshair)
        sp, org, dims = st.spacing, st.origin, st.dims
        w = st.voxel_to_world(self.app.cursor)
        lo = [org[a] for a in range(3)]
        hi = [org[a] + (dims[a] - 1) * sp[a] for a in range(3)]
        o = self.orientation
        eps = 0.55 * sp[o]
        p = list(w)
        p[o] = w[o] + eps
        a1, a2 = [a for a in range(3) if a != o]
        pts = []
        for axis, other in ((a1, a2), (a2, a1)):
            for end in (lo[axis], hi[axis]):
                q = list(p)
                q[axis] = end
                pts.append(q)
        # pts = [a1_lo, a1_hi, a2_lo, a2_hi]
        for n, q in enumerate(pts):
            self.cross_pts.SetPoint(n, *q)
        self.cross_pts.Modified()

    # -- data --------------------------------------------------------------
    def set_study(self, study):
        self.ren.RemoveViewProp(self.img_actor)
        self.ren.RemoveViewProp(self.lab_actor)
        if study is None:
            self.render()
            return

        self.orientation = plane_axis(study.codes, self.plane)
        self.img_mapper.SetOrientation(self.orientation)
        self.lab_mapper.SetOrientation(self.orientation)
        self.img_mapper.SetInputData(study.image)
        self.ren.AddViewProp(self.img_actor)

        if study.label is not None:
            self.lab_mapper.SetInputData(study.label)
            self.ren.AddViewProp(self.lab_actor)
            self.refresh_label_lut()

        n = study.dims[self.orientation]
        self.slice_index = n // 2
        self.slider.blockSignals(True)
        self.slider.setRange(0, max(0, n - 1))
        self.slider.setValue(self.slice_index)
        self.slider.blockSignals(False)

        self.apply_window_level()
        self.reset_camera()
        self.apply_slice()

    def refresh_label_lut(self):
        st = self.app.study
        if st is None or st.label is None:
            return
        ids = st.label_ids()
        hi = max([1] + ids)
        lut = vtk.vtkLookupTable()
        lut.SetNumberOfTableValues(hi + 1)
        lut.SetTableRange(0, hi)
        lut.SetTableValue(0, 0, 0, 0, 0.0)
        for i in range(1, hi + 1):
            r, g, b = label_color(i)
            on = self.app.label_visible.get(i, True)
            lut.SetTableValue(i, r, g, b, 1.0 if on else 0.0)
        lut.Build()
        p = self.lab_actor.GetProperty()
        p.SetLookupTable(lut)
        p.SetUseLookupTableScalarRange(True)
        p.SetOpacity(self.app.label_alpha_2d)

    def apply_slice(self):
        st = self.app.study
        if st is None:
            return
        n = st.dims[self.orientation] - 1
        self.slice_index = int(np.clip(self.slice_index, 0, n))
        self.img_mapper.SetSliceNumber(self.slice_index)
        self.lab_mapper.SetSliceNumber(self.slice_index)
        self.lab_actor.SetVisibility(self.app.show_labels and st.label is not None)
        if self.slider.value() != self.slice_index:
            self.slider.blockSignals(True)
            self.slider.setValue(self.slice_index)
            self.slider.blockSignals(False)

        pos = st.codes[self.orientation]
        here = pos if True else pos
        self.corner.SetText(2, "%s" % PLANE_TITLE[self.plane].upper())
        self.corner.SetText(3, "%d / %d   %s" % (self.slice_index + 1, n + 1, here))
        self.corner.SetText(0, "WW %d  WL %d" % (self.app.ww, self.app.wl))
        self.corner.SetText(1, "%.1f mm" % (st.origin[self.orientation]
                                            + self.slice_index * st.spacing[self.orientation]))
        self.update_crosshair()

    def apply_window_level(self):
        p = self.img_actor.GetProperty()
        p.SetColorWindow(self.app.ww_native())
        p.SetColorLevel(self.app.wl_native())

    # -- camera ------------------------------------------------------------
    def reset_camera(self):
        st = self.app.study
        codes = st.codes if st else CODE_RAS
        if self.plane == "axial":
            pos_dir, _, _ = dir_for(codes, "I")          # 아래에서 위로 (radiological)
            up_dir, _, _ = dir_for(codes, "A")
        elif self.plane == "coronal":
            pos_dir, _, _ = dir_for(codes, "A")
            up_dir, _, _ = dir_for(codes, "S")
        else:
            pos_dir, _, _ = dir_for(codes, "L")
            up_dir, _, _ = dir_for(codes, "S")

        cam = self.ren.GetActiveCamera()
        cam.ParallelProjectionOn()
        cam.SetFocalPoint(0, 0, 0)
        cam.SetPosition(*pos_dir)
        cam.SetViewUp(*up_dir)
        self.ren.ResetCamera()

        view_dir = [-v for v in pos_dir]
        right = cross(view_dir, up_dir)
        self.edge_text["right"].SetInput(vec_to_letter(codes, right))
        self.edge_text["left"].SetInput(vec_to_letter(codes, [-v for v in right]))
        self.edge_text["top"].SetInput(vec_to_letter(codes, up_dir))
        self.edge_text["bottom"].SetInput(vec_to_letter(codes, [-v for v in up_dir]))

    def zoom(self, f):
        cam = self.ren.GetActiveCamera()
        cam.SetParallelScale(max(1e-4, cam.GetParallelScale() / f))
        self.render()

    # -- events ------------------------------------------------------------
    def _slider_moved(self, v):
        self.slice_index = v
        c = list(self.app.cursor)
        c[self.orientation] = v
        self.app.set_cursor(c)

    def step(self, d):
        self.slice_index += d
        c = list(self.app.cursor)
        c[self.orientation] = int(np.clip(self.slice_index, 0,
                                          self.app.study.dims[self.orientation] - 1))
        self.app.set_cursor(c)

    def _world_to_ijk(self, w):
        st = self.app.study
        sp, org = st.spacing, st.origin
        return [int(np.clip(round((w[a] - org[a]) / sp[a]), 0, st.dims[a] - 1))
                for a in range(3)]

    def _pick(self):
        if self.app.study is None:
            return None
        x, y = self.iren.GetEventPosition()
        if not self.picker.Pick(x, y, 0, self.ren):
            return None
        return self._world_to_ijk(self.picker.GetPickPosition())

    def pick_here(self):
        ijk = self._pick()
        if ijk is None:
            return
        ijk[self.orientation] = self.slice_index
        self.app.set_cursor(ijk)

    def hover_here(self):
        ijk = self._pick()
        if ijk is not None:
            ijk[self.orientation] = self.slice_index
            self.app.report_voxel(ijk)

    def window_level(self):
        p = self.img_actor.GetProperty()
        return p.GetColorWindow(), p.GetColorLevel()

    def render(self):
        self.widget.GetRenderWindow().Render()


# ===========================================================================
# 3D pane
# ===========================================================================
class SceneStyle(vtk.vtkInteractorStyleTrackballCamera):
    def __init__(self, pane):
        super().__init__()
        self.pane = pane
        self.AddObserver("LeftButtonPressEvent", self._down)

    def _down(self, obj, evt):
        self.OnLeftButtonDown()
        if self.pane.app.tool == "pan":
            self.EndRotate()
            self.StartPan()


class ScenePane(QtWidgets.QFrame):
    """볼륨 레이캐스팅 + label surface."""

    def __init__(self, app):
        super().__init__()
        self.app = app
        self.plane = "3d"
        self.setObjectName("pane")

        self.widget = QVTKRenderWindowInteractor(self)
        lay = QtWidgets.QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.addWidget(self.widget)

        self.ren = vtk.vtkRenderer()
        self.bg_name = BG_DEFAULT
        self.widget.GetRenderWindow().AddRenderer(self.ren)
        self.iren = self.widget.GetRenderWindow().GetInteractor()
        self.iren.SetInteractorStyle(SceneStyle(self))

        self.mapper = vtk.vtkSmartVolumeMapper()
        self.mapper.SetBlendModeToComposite()
        # 회전 중에도 샘플 간격을 그대로 유지한다.
        # 이 두 옵션이 켜져 있으면 드래그하는 동안 VTK 가 프레임률을 지키려고
        # 레이 샘플 간격을 크게 벌리는데, 그때 label 표면 위로 나선형 줄무늬가 생긴다.
        self.mapper.SetAutoAdjustSampleDistances(False)
        self.mapper.SetInteractiveAdjustSampleDistances(False)
        self.prop = vtk.vtkVolumeProperty()
        self.prop.SetInterpolationTypeToLinear()
        self.prop.ShadeOn()
        self.prop.SetSpecularPower(20)
        self.volume = vtk.vtkVolume()
        self.volume.SetMapper(self.mapper)
        self.volume.SetProperty(self.prop)

        self.outline_actor = vtk.vtkActor()
        self.outline_actor.GetProperty().SetColor(0.80, 0.40, 1.00)   # PPT purple
        self.outline_actor.GetProperty().SetLineWidth(1.8)
        self.label_actors = {}

        self.corner = vtk.vtkCornerAnnotation()
        self.corner.SetMaximumFontSize(13)
        self.corner.GetTextProperty().SetColor(0.29, 0.43, 0.58)
        self.corner.GetTextProperty().SetFontFamilyToCourier()
        self.corner.SetText(2, "3D RENDERING")
        self.ren.AddViewProp(self.corner)

        # 보라색 bounding box 여섯 면에 R / L / A / P / S / I 를 직접 써 붙인다.
        # (vtkBillboardTextActor3D 는 항상 카메라를 향하므로 회전해도 읽힌다)
        self.axis_labels = {}
        for key in ("x+", "x-", "y+", "y-", "z+", "z-"):
            t = vtk.vtkBillboardTextActor3D()
            t.SetInput("")
            tp = t.GetTextProperty()
            tp.SetColor(0.36, 0.16, 0.50)          # 박스와 같은 계열의 진한 보라
            tp.SetFontFamilyToArial()
            tp.SetFontSize(21)
            tp.BoldOn()
            tp.SetJustificationToCentered()
            tp.SetVerticalJustificationToCentered()
            t.SetVisibility(False)
            self.ren.AddViewProp(t)
            self.axis_labels[key] = t

    def set_background(self, name):
        """3D 배경을 Blue / Black / Navy 로 바꾸고, 글자색을 배경에 맞춘다."""
        spec = BG_PRESETS.get(name, BG_PRESETS[BG_DEFAULT])
        self.bg_name = name if name in BG_PRESETS else BG_DEFAULT
        if spec[0] == "gradient":
            self.ren.GradientBackgroundOn()
            self.ren.SetBackground(*spec[2])      # 아래쪽
            self.ren.SetBackground2(*spec[1])     # 위쪽
            dark = False
        else:
            self.ren.GradientBackgroundOff()
            self.ren.SetBackground(*spec[1])
            dark = True

        letter = (0.78, 0.56, 1.00) if dark else (0.30, 0.10, 0.46)
        for t in self.axis_labels.values():
            t.GetTextProperty().SetColor(*letter)
        self.corner.GetTextProperty().SetColor(
            *((0.45, 0.57, 0.75) if dark else (0.26, 0.30, 0.48)))
        self.render()

    def start(self):
        self.set_background(self.bg_name)

    def place_axis_labels(self, study):
        if study is None:
            for t in self.axis_labels.values():
                t.SetVisibility(False)
            return
        b = study.image.GetBounds()
        cx, cy, cz = (b[0] + b[1]) / 2.0, (b[2] + b[3]) / 2.0, (b[4] + b[5]) / 2.0
        ex, ey, ez = b[1] - b[0], b[3] - b[2], b[5] - b[4]
        pad = 0.055
        c = study.codes
        spec = {
            "x+": ((b[1] + ex * pad, cy, cz), c[0]),
            "x-": ((b[0] - ex * pad, cy, cz), OPP[c[0]]),
            "y+": ((cx, b[3] + ey * pad, cz), c[1]),
            "y-": ((cx, b[2] - ey * pad, cz), OPP[c[1]]),
            "z+": ((cx, cy, b[5] + ez * pad), c[2]),
            "z-": ((cx, cy, b[4] - ez * pad), OPP[c[2]]),
        }
        for key, (pos, letter) in spec.items():
            t = self.axis_labels[key]
            t.SetPosition(*pos)
            t.SetInput(letter)
            t.SetVisibility(True)

    # -- data --------------------------------------------------------------
    def set_study(self, study):
        for a in self.label_actors.values():
            self.ren.RemoveActor(a)
        self.label_actors = {}
        self.ren.RemoveVolume(self.volume)
        self.ren.RemoveActor(self.outline_actor)
        if study is None:
            self.place_axis_labels(None)
            self.ren.ResetCamera()
            self.render()
            return

        self.place_axis_labels(study)
        self.mapper.SetInputData(study.image)
        # 샘플 간격을 고정한다 — 정지 화면과 회전 중 그림이 완전히 같아진다.
        # 큰 볼륨은 조금 성기게 잡아 회전이 느려지지 않게 하되, 값 자체는 고정이라
        # 움직일 때 줄무늬가 생기지 않는다.
        try:
            step = min(abs(v) for v in study.spacing if abs(v) > 1e-6)
        except ValueError:
            step = 1.0
        d = study.dims
        nvox = float(d[0]) * d[1] * d[2]
        factor = 0.5 if nvox <= 256 ** 3 else (0.75 if nvox <= 384 ** 3 else 1.0)
        self.mapper.SetSampleDistance(max(0.05, step * factor))
        self.apply_transfer()
        self.ren.AddVolume(self.volume)
        self.volume.SetVisibility(self.app.show_volume)

        outline = vtk.vtkOutlineFilter()
        outline.SetInputData(study.image)
        om = vtk.vtkPolyDataMapper()
        om.SetInputConnection(outline.GetOutputPort())
        self.outline_actor.SetMapper(om)
        self.ren.AddActor(self.outline_actor)

        if study.label is not None:
            self.build_label_surfaces(study)

        self.reset()

    def build_label_surfaces(self, study):
        ids = study.label_ids()
        if len(ids) > 6:
            QtWidgets.QApplication.setOverrideCursor(QtCore.Qt.WaitCursor)
        try:
            self._build_label_surfaces(study, ids)
        finally:
            if len(ids) > 6:
                QtWidgets.QApplication.restoreOverrideCursor()

    def _build_label_surfaces(self, study, ids):
        for lid in ids:
            try:
                contour = vtk.vtkDiscreteFlyingEdges3D()
            except AttributeError:
                contour = vtk.vtkDiscreteMarchingCubes()
            contour.SetInputData(study.label)
            contour.SetValue(0, lid)
            contour.Update()
            if contour.GetOutput().GetNumberOfPoints() == 0:
                continue
            smooth = vtk.vtkWindowedSincPolyDataFilter()
            smooth.SetInputConnection(contour.GetOutputPort())
            smooth.SetNumberOfIterations(18)
            smooth.SetPassBand(0.08)
            smooth.NonManifoldSmoothingOn()
            smooth.NormalizeCoordinatesOn()
            normals = vtk.vtkPolyDataNormals()
            normals.SetInputConnection(smooth.GetOutputPort())
            normals.SetFeatureAngle(60)
            mapper = vtk.vtkPolyDataMapper()
            mapper.SetInputConnection(normals.GetOutputPort())
            mapper.ScalarVisibilityOff()
            # 같은 자리에 겹치는 면끼리 z-fighting 하지 않도록
            mapper.SetResolveCoincidentTopologyToPolygonOffset()
            mapper.SetRelativeCoincidentTopologyPolygonOffsetParameters(-1.0, -1.0)
            actor = vtk.vtkActor()
            actor.SetMapper(mapper)
            r, g, b = label_color(lid)
            pr = actor.GetProperty()
            pr.SetColor(r, g, b)
            pr.SetAmbientColor(r, g, b)
            pr.SetDiffuseColor(r, g, b)
            pr.SetSpecularPower(LABEL_SPECULAR_POWER)
            pr.SetInterpolationToGouraud()
            pr.SetOpacity(self.app.label_alpha_3d)
            self.ren.AddActor(actor)
            self.label_actors[lid] = actor
        self.apply_shading()
        self.refresh_label_style()

    def apply_shading(self):
        """음영 세기를 label 표면과 볼륨에 함께 반영한다."""
        amb, dif, spc = shading_params(self.app.shade)
        for a in self.label_actors.values():
            pr = a.GetProperty()
            pr.SetAmbient(amb)
            pr.SetDiffuse(dif)
            pr.SetSpecular(spc)
        # 볼륨 렌더링도 같은 흐름으로 (조금 더 완만하게)
        self.prop.SetAmbient(0.20 + amb * 0.55)
        self.prop.SetDiffuse(0.35 + dif * 0.45)
        self.prop.SetSpecular(spc * 0.7)

    def refresh_label_style(self):
        for lid, a in self.label_actors.items():
            a.SetVisibility(self.app.show_labels and self.app.label_visible.get(lid, True))
            a.GetProperty().SetOpacity(self.app.label_alpha_3d)

    def apply_transfer(self):
        st = self.app.study
        if st is None:
            return
        lo_v, hi_v = st.scalar_range
        span = max(1.0, hi_v - lo_v)
        p = PRESETS[self.app.preset]
        t0 = lo_v + span * min(0.98, p["lo"] * self.app.threshold_scale)
        t1 = lo_v + span * p["hi"]
        if t1 <= t0:
            t1 = t0 + span * 0.05
        amax = min(1.0, p["opacity"] * self.app.volume_alpha)

        color = vtk.vtkColorTransferFunction()
        color.AddRGBPoint(lo_v, 0.20, 0.06, 0.06)
        color.AddRGBPoint(t0, 0.55, 0.24, 0.20)
        color.AddRGBPoint((t0 + t1) / 2.0, 0.90, 0.62, 0.48)
        color.AddRGBPoint(t1, 0.99, 0.94, 0.88)
        color.AddRGBPoint(hi_v, 1.00, 0.98, 0.95)

        opacity = vtk.vtkPiecewiseFunction()
        opacity.AddPoint(lo_v, 0.0)
        opacity.AddPoint(t0, 0.0)
        opacity.AddPoint(t0 + (t1 - t0) * 0.35, amax * 0.55)
        opacity.AddPoint(t1, amax)
        opacity.AddPoint(hi_v, amax)

        grad = vtk.vtkPiecewiseFunction()
        grad.AddPoint(0.0, 0.35)
        grad.AddPoint(span * 0.08, 1.0)

        self.prop.SetColor(color)
        self.prop.SetScalarOpacity(opacity)
        self.prop.SetGradientOpacity(grad)

    def set_volume_visible(self, on):
        self.volume.SetVisibility(on)

    def zoom(self, f):
        self.ren.GetActiveCamera().Zoom(f)
        self.render()

    def reset(self):
        self.ren.ResetCamera()
        cam = self.ren.GetActiveCamera()
        cam.Azimuth(-35)
        cam.Elevation(18)
        cam.OrthogonalizeViewUp()
        cam.Zoom(1.35)
        self.render()

    def render(self):
        self.widget.GetRenderWindow().Render()


# ===========================================================================
# stylesheet
# ===========================================================================
STYLESHEET = """
QMainWindow, QWidget {{ background:{ground}; color:{ink};
  font-family:"IBM Plex Sans","Malgun Gothic","Segoe UI",sans-serif; font-size:12px; }}
QMenuBar {{ background:{chrome}; color:{ink}; border-bottom:1px solid {edge}; padding:2px 4px; }}
QMenuBar::item {{ padding:5px 12px; background:transparent; }}
QMenuBar::item:selected {{ background:{railhi}; }}
QMenu {{ background:#102446; border:1px solid {edge}; padding:4px 0; }}
QMenu::item {{ padding:6px 24px 6px 14px; }}
QMenu::item:selected {{ background:{railhi}; }}
QMenu::item:disabled {{ color:#5f779c; font-style:italic; }}
QMenu::separator {{ height:1px; background:{edge}; margin:4px 0; }}
QFrame#tab {{ background:#0c1a3a; border:1px solid {edge}; }}
QFrame#tab[active="true"] {{ background:{tabon}; border-color:#4a90d9; }}
QFrame#tabfill {{ background:#0b1735; border:1px solid #16294c; }}
QToolButton#tabbtn {{ color:{inkdim}; text-align:left; padding:0; min-width:0;
  border:none; font-family:"IBM Plex Mono","Consolas",monospace; font-size:12px; }}
QFrame#tab[active="true"] QToolButton#tabbtn {{ color:#ffffff; }}
QToolButton#tabbtn:hover {{ color:{ink}; }}
QToolButton#tabclose {{ color:#5f779c; border:none; padding:0; min-width:0;
  font-family:"IBM Plex Mono","Consolas",monospace; }}
QToolButton#tabclose:hover {{ color:#ffffff; background:#c0392b; }}
QScrollArea#labelscroll {{ background:transparent; border:none; }}
QScrollArea#labelscroll > QWidget > QWidget {{ background:transparent; }}
QScrollBar:horizontal {{ height:6px; background:#0f2044; }}
QScrollBar::handle:horizontal {{ background:{edge}; min-width:24px; }}
QScrollBar::add-line, QScrollBar::sub-line {{ width:0; height:0; }}
QToolBar {{ background:{rail}; border-right:1px solid {edge}; spacing:1px; padding:5px 3px; }}
QToolButton {{ color:{inkdim}; padding:9px 2px; min-width:62px; border:1px solid transparent; }}
QToolButton:hover {{ background:#173a6c; color:{ink}; }}
QToolButton:checked {{ background:{railhi}; color:#ffffff; border-color:#3d76c4; }}
QStatusBar {{ background:{chrome}; border-top:1px solid {edge}; color:{inkdim};
  font-family:"IBM Plex Mono","Consolas",monospace; font-size:11px; }}
QStatusBar::item {{ border:none; }}
QStatusBar QLabel {{ padding:0 10px; border-right:1px solid {edge}; }}
QLabel#brand {{ font-size:15px; font-weight:700; letter-spacing:1px; padding:3px 12px 3px 6px; }}
QLabel#sect {{ color:#5f779c; font-size:9px; letter-spacing:2px; padding:0 2px; }}
QFrame#pane {{ border:1px solid {edge}; background:#03060e; }}
QFrame#ctl {{ background:{chrome}; border-top:1px solid {edge}; }}
QComboBox {{ background:#12244a; border:1px solid {edge}; padding:3px 8px; min-width:78px; }}
QComboBox QAbstractItemView {{ background:#102446; selection-background-color:{railhi}; }}
QSpinBox {{ background:#12244a; border:1px solid {edge}; padding:2px 4px; min-width:52px;
  font-family:"IBM Plex Mono","Consolas",monospace; }}
QCheckBox {{ color:{inkdim}; spacing:5px; }}
QCheckBox:hover {{ color:{ink}; }}
QSlider::groove:horizontal {{ height:3px; background:#26456f; }}
QSlider::handle:horizontal {{ background:{accent}; width:9px; height:13px; margin:-6px 0; }}
QSlider#slice {{ background:#0a152e; height:14px; }}
QSlider#slice::groove:horizontal {{ height:3px; background:#1d3760; }}
QSlider#slice::handle:horizontal {{ background:{amber}; width:9px; height:12px; margin:-5px 0; }}
QPushButton {{ background:#12244a; border:1px solid {edge}; padding:4px 12px; }}
QPushButton:hover {{ background:#1b3a68; }}
""".format(ground=C_GROUND, chrome=C_CHROME, rail=C_RAIL, railhi=C_RAIL_HI,
           edge=C_EDGE, ink=C_INK, inkdim=C_INK_DIM, accent=C_ACCENT,
           amber=C_AMBER, tabon=C_TAB_ON)


# ===========================================================================
# 파일 탭 — 최대 10개를 2줄로 배치 (QTabBar 는 여러 줄을 지원하지 않아 직접 만든다)
# ===========================================================================
class StudyTabs(QtWidgets.QWidget):

    currentChanged = QtCore.pyqtSignal(int)
    closeRequested = QtCore.pyqtSignal(int)

    COLS = (MAX_STUDIES + 1) // 2  # 항상 2줄이 되도록 열 수를 정한다

    def __init__(self, parent=None):
        super().__init__(parent)
        self._names = []
        self._subs = []
        self._current = -1
        self._buttons = []
        self.grid = QtWidgets.QGridLayout(self)
        self.grid.setContentsMargins(0, 0, 0, 0)
        self.grid.setHorizontalSpacing(1)
        self.grid.setVerticalSpacing(1)
        for c in range(self.COLS):
            self.grid.setColumnStretch(c, 1)

    # -- 공개 API (QTabBar 와 같은 이름) ----------------------------------
    def count(self):
        return len(self._names)

    def currentIndex(self):
        return self._current

    def addTab(self, name, sub=""):
        self._names.append(name)
        self._subs.append(sub)
        self._relayout()
        return len(self._names) - 1

    def setTabSub(self, i, sub):
        if 0 <= i < len(self._subs):
            self._subs[i] = sub
            self._relayout()

    def removeTab(self, i):
        if not (0 <= i < len(self._names)):
            return
        self._names.pop(i)
        self._subs.pop(i)
        if self._current >= len(self._names):
            self._current = len(self._names) - 1
        self._relayout()
        self.currentChanged.emit(self._current)

    def clear(self):
        self._names = []
        self._subs = []
        self._current = -1
        self._relayout()

    def setCurrentIndex(self, i, force=False):
        if not (0 <= i < len(self._names)):
            self._sync_checked()
            return
        if i == self._current and not force:
            self._sync_checked()
            return
        self._current = i
        self._sync_checked()
        self.currentChanged.emit(i)

    # -- 내부 ------------------------------------------------------------
    def _relayout(self):
        while self.grid.count():
            it = self.grid.takeAt(0)
            if it.widget():
                it.widget().deleteLater()
        self._buttons = []
        if not self._names:
            self._current = -1

        for i, name in enumerate(self._names):
            r, c = divmod(i, self.COLS)
            self._buttons.append(self._make_tab(i, name, self._subs[i]))
            self.grid.addWidget(self._buttons[-1], r, c)

        # 남는 칸은 빈 판으로 채워 줄 높이를 유지한다
        rows = 2 if len(self._names) > self.COLS else 1
        for i in range(len(self._names), rows * self.COLS):
            r, c = divmod(i, self.COLS)
            filler = QtWidgets.QFrame()
            filler.setObjectName("tabfill")
            filler.setFixedHeight(30)
            self.grid.addWidget(filler, r, c)
        self._sync_checked()

    def _make_tab(self, i, name, sub):
        w = QtWidgets.QFrame()
        w.setObjectName("tab")
        w.setFixedHeight(30)
        w.setMinimumWidth(86)
        h = QtWidgets.QHBoxLayout(w)
        h.setContentsMargins(7, 0, 3, 0)
        h.setSpacing(3)

        btn = QtWidgets.QToolButton()
        btn.setObjectName("tabbtn")
        btn.setToolButtonStyle(QtCore.Qt.ToolButtonTextOnly)
        btn.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Preferred)
        fm = btn.fontMetrics()
        btn.setText(fm.elidedText(name, QtCore.Qt.ElideMiddle, 118))
        btn.setToolTip("%s\n%s" % (name, sub) if sub else name)
        btn.clicked.connect(lambda _c=False, k=i: self.setCurrentIndex(k))
        h.addWidget(btn, 1)

        close = QtWidgets.QToolButton()
        close.setObjectName("tabclose")
        close.setText("x")
        close.setFixedSize(14, 14)
        close.setToolTip("close")
        close.clicked.connect(lambda _c=False, k=i: self.closeRequested.emit(k))
        h.addWidget(close, 0)
        return w

    def _sync_checked(self):
        for i, w in enumerate(self._buttons):
            w.setProperty("active", i == self._current)
            w.style().unpolish(w)
            w.style().polish(w)


# ===========================================================================
# Main window
# ===========================================================================
class ClarusViewer(QtWidgets.QMainWindow):

    def __init__(self, studies):
        super().__init__()
        self.setWindowTitle(APP_NAME)
        self.resize(1560, 980)
        self.setStyleSheet(STYLESHEET)

        self.studies = list(studies)
        self.study = None
        self.tool = "cross"
        self.show_labels = True
        self.show_volume = True
        self.show_crosshair = True
        self.label_visible = {}          # {class id: bool}, 기본값 True
        self.label_alpha_2d = 0.55
        self.label_alpha_3d = 1.0
        self.volume_alpha = 1.0
        self.threshold_scale = 1.0
        self.preset = "Vessel"
        self.bg_name = BG_DEFAULT
        self.shade = SHADE_DEFAULT
        self.ww, self.wl = PRESETS["Vessel"]["ww"], PRESETS["Vessel"]["wl"]
        self.cursor = [0, 0, 0]
        self._maximized = None
        self._updating = False

        self._build_menu()
        self._build_toolbar()
        self._build_center()
        self._build_status()
        self._build_shortcuts()

        self.tabs.currentChanged.connect(self.select_study)
        for st in self.studies:
            self.tabs.addTab(st.name, st.modality)
        self.setAcceptDrops(True)
        QtCore.QTimer.singleShot(0, self._start)

    # ---------------------------------------------------------------- chrome
    def _build_menu(self):
        mb = self.menuBar()
        f = mb.addMenu("File")
        f.addAction("Add data…", self.add_data, "Ctrl+O")
        f.addAction("Add DICOM folder…", self.add_dicom)
        f.addAction("Add annotation…", self.add_annotation, "Ctrl+L")
        f.addSeparator()
        f.addAction("Save screenshot…", self.save_screenshot, "Ctrl+S")
        f.addSeparator()
        f.addAction("Close current study", self.close_study, "Ctrl+W")
        f.addSeparator()
        f.addAction("Exit", self.close, "Ctrl+Q")
        # Edit 자리 — 단축키 목록
        self.act_hotkey = QtWidgets.QAction("Hotkey", self)
        self.act_hotkey.setToolTip("설정되어 있는 단축키를 보여 줍니다")
        self.act_hotkey.triggered.connect(self.show_hotkeys)
        mb.addAction(self.act_hotkey)

        # View — 3D 배경색
        v = mb.addMenu("View")
        bgm = v.addMenu("3D background color")
        self.bg_group = QtWidgets.QActionGroup(self)
        self.bg_group.setExclusive(True)
        self.bg_actions = {}
        for name in BG_PRESETS:
            a = QtWidgets.QAction(name, self, checkable=True)
            a.setChecked(name == BG_DEFAULT)
            a.triggered.connect(lambda _c=False, n=name: self.set_background(n))
            self.bg_group.addAction(a)
            bgm.addAction(a)
            self.bg_actions[name] = a

        # View 바로 옆 — 열려 있는 데이터를 한꺼번에 화면에서 지운다
        self.act_delete_all = QtWidgets.QAction("Delete all", self)
        self.act_delete_all.setShortcut("Ctrl+Shift+D")
        self.act_delete_all.setToolTip("열려 있는 모든 데이터를 화면에서 지웁니다 (Ctrl+Shift+D)")
        self.act_delete_all.triggered.connect(self.delete_all)
        mb.addAction(self.act_delete_all)

        mb.setCornerWidget(self._make_brand(), QtCore.Qt.TopLeftCorner)

    def _make_brand(self):
        """메뉴줄 왼쪽 워드마크. 원본 로고 이미지를 그대로 쓴다."""
        lb = QtWidgets.QLabel()
        lb.setObjectName("brand")
        try:
            pm = QtGui.QPixmap()
            if pm.loadFromData(base64.b64decode(LOGO_PNG_B64), "PNG") and not pm.isNull():
                pm = pm.scaledToHeight(44, QtCore.Qt.SmoothTransformation)
                pm.setDevicePixelRatio(2.0)          # 22px 로 또렷하게 그려진다
                lb.setPixmap(pm)
                lb.setContentsMargins(8, 3, 14, 3)
                return lb
        except Exception:                                     # noqa: BLE001
            pass
        lb.setText('<span style="color:#ffffff">CLARUS</span>'
                   '<span style="color:%s">-N</span>'
                   '<span style="color:%s;font-size:10px"> VIEWER</span>'
                   % (C_ACCENT, C_AMBER))
        return lb

    def _build_toolbar(self):
        tb = QtWidgets.QToolBar("tools")
        tb.setOrientation(QtCore.Qt.Vertical)
        tb.setMovable(False)
        tb.setToolButtonStyle(QtCore.Qt.ToolButtonTextOnly)
        self.addToolBar(QtCore.Qt.LeftToolBarArea, tb)

        group = QtWidgets.QActionGroup(self)
        group.setExclusive(True)
        self.tool_actions = {}
        for key, text, tip in (
            ("pan", "Pan", "드래그로 이동 (2D · 3D)"),
            ("rotate", "Rotation", "3D 뷰에서 드래그하면 회전"),
            ("cross", "Cross", "클릭하면 세 평면이 함께 이동"),
            ("wl", "W/L", "2D 에서 드래그: 좌우=window width, 상하=level"),
        ):
            a = QtWidgets.QAction(text, self, checkable=True)
            a.setToolTip(tip)
            a.triggered.connect(lambda _c, k=key: self.set_tool(k))
            group.addAction(a)
            tb.addAction(a)
            self.tool_actions[key] = a
        self.tool_actions["cross"].setChecked(True)

        tb.addSeparator()
        act_in = QtWidgets.QAction("+", self); act_in.setToolTip("확대")
        act_in.triggered.connect(lambda: self.zoom(1.25))
        tb.addAction(act_in)
        act_out = QtWidgets.QAction("−", self); act_out.setToolTip("축소")
        act_out.triggered.connect(lambda: self.zoom(1 / 1.25))
        tb.addAction(act_out)

        tb.addSeparator()
        self.act_labels = QtWidgets.QAction("Label\non/off", self, checkable=True)
        self.act_labels.setChecked(True)
        self.act_labels.setToolTip("annotation 표시 (L)")
        self.act_labels.triggered.connect(self.toggle_labels)
        tb.addAction(self.act_labels)

        self.act_cross = QtWidgets.QAction("Cross\nhair", self, checkable=True)
        self.act_cross.setChecked(True)
        self.act_cross.triggered.connect(self.toggle_crosshair)
        tb.addAction(self.act_cross)

        tb.addSeparator()
        act_reset = QtWidgets.QAction("Reset", self)
        act_reset.setToolTip("카메라 · 슬라이스 초기화 (R)")
        act_reset.triggered.connect(self.reset_views)
        tb.addAction(act_reset)

    def _build_center(self):
        central = QtWidgets.QWidget()
        v = QtWidgets.QVBoxLayout(central)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(0)

        self.tabs = StudyTabs()
        self.tabs.closeRequested.connect(self.close_study_at)
        v.addWidget(self.tabs)

        host = QtWidgets.QWidget()
        self.grid = QtWidgets.QGridLayout(host)
        self.grid.setContentsMargins(1, 1, 1, 1)
        self.grid.setSpacing(1)

        self.pane_axial = SlicePane(self, "axial")
        self.pane_coronal = SlicePane(self, "coronal")
        self.pane_sagittal = SlicePane(self, "sagittal")
        self.pane_3d = ScenePane(self)
        self.slice_panes = [self.pane_axial, self.pane_coronal, self.pane_sagittal]
        self.panes = [self.pane_axial, self.pane_3d, self.pane_coronal, self.pane_sagittal]

        # PPT 배치: 좌상 Axial | 우상 3D / 좌하 Coronal | 우하 Sagittal
        self.grid.addWidget(self.pane_axial, 0, 0)
        self.grid.addWidget(self.pane_3d, 0, 1)
        self.grid.addWidget(self.pane_coronal, 1, 0)
        self.grid.addWidget(self.pane_sagittal, 1, 1)
        for p in self.panes:
            p.widget.setAcceptDrops(True)
            p.widget.installEventFilter(self)

        v.addWidget(host, 1)
        v.addWidget(self._build_controls())
        self.setCentralWidget(central)

    def _sep(self):
        line = QtWidgets.QFrame()
        line.setFrameShape(QtWidgets.QFrame.VLine)
        line.setStyleSheet("color:%s;" % C_EDGE)
        return line

    def _build_controls(self):
        box = QtWidgets.QFrame()
        box.setObjectName("ctl")
        outer = QtWidgets.QVBoxLayout(box)
        outer.setContentsMargins(10, 6, 10, 6)
        outer.setSpacing(6)

        # --- row 1 : 2D + annotation -------------------------------------
        r1 = QtWidgets.QHBoxLayout(); r1.setSpacing(8)
        lb = QtWidgets.QLabel("2D"); lb.setObjectName("sect"); r1.addWidget(lb)

        self.cb_preset = QtWidgets.QComboBox()
        self.cb_preset.addItems(list(PRESETS))
        self.cb_preset.currentTextChanged.connect(self.set_preset)
        r1.addWidget(self.cb_preset)

        r1.addWidget(QtWidgets.QLabel("WW"))
        self.sp_ww = QtWidgets.QSpinBox(); self.sp_ww.setRange(1, 512)
        self.sp_ww.setValue(self.ww)
        self.sp_ww.valueChanged.connect(self._wl_spin_changed)
        r1.addWidget(self.sp_ww)
        r1.addWidget(QtWidgets.QLabel("WL"))
        self.sp_wl = QtWidgets.QSpinBox(); self.sp_wl.setRange(-256, 512)
        self.sp_wl.setValue(self.wl)
        self.sp_wl.valueChanged.connect(self._wl_spin_changed)
        r1.addWidget(self.sp_wl)

        r1.addWidget(self._sep())
        lb = QtWidgets.QLabel("ANNOTATION"); lb.setObjectName("sect"); r1.addWidget(lb)
        self.label_box = QtWidgets.QHBoxLayout()
        self.label_box.setContentsMargins(2, 0, 2, 0)
        self.label_box.setSpacing(12)
        holder = QtWidgets.QWidget()
        holder.setLayout(self.label_box)
        scroll = QtWidgets.QScrollArea()
        scroll.setObjectName("labelscroll")
        scroll.setWidget(holder)
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QtWidgets.QFrame.NoFrame)
        scroll.setVerticalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOff)
        scroll.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarAsNeeded)
        scroll.setFixedHeight(30)
        scroll.setMinimumWidth(240)
        r1.addWidget(scroll, 1)
        self.label_checks = {}

        r1.addWidget(QtWidgets.QLabel("2D α"))
        self.sl_a2 = QtWidgets.QSlider(QtCore.Qt.Horizontal)
        self.sl_a2.setRange(0, 100); self.sl_a2.setValue(55); self.sl_a2.setFixedWidth(90)
        self.sl_a2.valueChanged.connect(self._label_alpha_changed)
        r1.addWidget(self.sl_a2)
        r1.addWidget(QtWidgets.QLabel("3D α"))
        self.sl_a3 = QtWidgets.QSlider(QtCore.Qt.Horizontal)
        self.sl_a3.setRange(10, 100); self.sl_a3.setValue(100); self.sl_a3.setFixedWidth(90)
        self.sl_a3.valueChanged.connect(self._label_alpha_changed)
        r1.addWidget(self.sl_a3)
        r1.addStretch(1)
        outer.addLayout(r1)

        # --- row 2 : 3D ---------------------------------------------------
        r2 = QtWidgets.QHBoxLayout(); r2.setSpacing(8)
        lb = QtWidgets.QLabel("3D"); lb.setObjectName("sect"); r2.addWidget(lb)

        self.cb_volume = QtWidgets.QCheckBox("volume rendering")
        self.cb_volume.setChecked(True)
        self.cb_volume.toggled.connect(self._volume_toggled)
        r2.addWidget(self.cb_volume)

        r2.addWidget(QtWidgets.QLabel("opacity"))
        self.sl_op = QtWidgets.QSlider(QtCore.Qt.Horizontal)
        self.sl_op.setRange(5, 200); self.sl_op.setValue(100); self.sl_op.setFixedWidth(130)
        self.sl_op.valueChanged.connect(self._scene_changed)
        r2.addWidget(self.sl_op)

        r2.addWidget(QtWidgets.QLabel("threshold"))
        self.sl_th = QtWidgets.QSlider(QtCore.Qt.Horizontal)
        self.sl_th.setRange(40, 160); self.sl_th.setValue(100); self.sl_th.setFixedWidth(130)
        self.sl_th.valueChanged.connect(self._scene_changed)
        r2.addWidget(self.sl_th)

        lb_sh = QtWidgets.QLabel("shading")
        lb_sh.setToolTip("왼쪽 = 평평(색이 또렷) · 오른쪽 = 강한 음영(원근이 뚜렷)")
        r2.addWidget(lb_sh)
        self.sl_shade = QtWidgets.QSlider(QtCore.Qt.Horizontal)
        self.sl_shade.setRange(0, 100)
        self.sl_shade.setValue(int(SHADE_DEFAULT * 100))
        self.sl_shade.setFixedWidth(110)
        self.sl_shade.setToolTip(lb_sh.toolTip())
        self.sl_shade.valueChanged.connect(self._shade_changed)
        r2.addWidget(self.sl_shade)

        r2.addWidget(self._sep())
        lb = QtWidgets.QLabel("ORIENTATION"); lb.setObjectName("sect"); r2.addWidget(lb)
        self.cb_orient = QtWidgets.QComboBox()
        self.cb_orient.addItems(["파일 정보", "RAS", "LPS"])
        self.cb_orient.currentTextChanged.connect(self._orient_changed)
        r2.addWidget(self.cb_orient)
        self.lb_codes = QtWidgets.QLabel("—")
        self.lb_codes.setStyleSheet("font-family:'IBM Plex Mono',Consolas,monospace;"
                                    "color:%s;" % C_INK_DIM)
        r2.addWidget(self.lb_codes)

        r2.addStretch(1)
        btn = QtWidgets.QPushButton("Reset views")
        btn.clicked.connect(self.reset_views)
        r2.addWidget(btn)
        outer.addLayout(r2)
        return box

    def _build_status(self):
        sb = self.statusBar()
        self.lb_study = QtWidgets.QLabel("—")
        self.lb_dims = QtWidgets.QLabel("—")
        self.lb_pos = QtWidgets.QLabel("i — j — k —")
        self.lb_mm = QtWidgets.QLabel("— mm")
        self.lb_val = QtWidgets.QLabel("value —")
        self.lb_lab = QtWidgets.QLabel("label —")
        self.lb_cls = QtWidgets.QLabel("classes —")
        self.lb_msg = QtWidgets.QLabel(
            "파일을 창에 끌어다 놓으면 열립니다 (최대 %d개) · pane 더블클릭 = 최대화 · "
            "휠 = slice · L = label · R = reset" % MAX_STUDIES)
        for w in (self.lb_study, self.lb_dims, self.lb_cls, self.lb_pos, self.lb_mm,
                  self.lb_val, self.lb_lab):
            sb.addWidget(w)
        sb.addWidget(self.lb_msg, 1)

    def _build_shortcuts(self):
        def sc(seq, fn):
            QtWidgets.QShortcut(QtGui.QKeySequence(seq), self, activated=fn)
        for n in range(1, 11):                      # F1 ~ F10 = Segment_1 ~ Segment_10
            sc("F%d" % n, lambda i=n: self.toggle_segment(i))
        sc("F12", self.capture_beside_label)
        sc("L", lambda: self.act_labels.trigger())
        sc("R", self.reset_views)
        sc("C", lambda: self.act_cross.trigger())
        for i, p in enumerate(self.panes, start=1):
            sc(str(i), lambda p=p: self._toggle_max(p))
        sc("Escape", self._unmaximize)
        sc("Up", lambda: self._nudge(+1))
        sc("Down", lambda: self._nudge(-1))

    # -------------------------------------------------------------- lifecycle
    def _start(self):
        for p in self.panes:
            p.widget.Initialize()
            p.widget.Start()
        self.pane_3d.start()
        if self.studies:
            self.tabs.setCurrentIndex(0, force=True)

    def closeEvent(self, e):
        for p in self.panes:
            p.widget.Finalize()
        e.accept()

    # ----------------------------------------------------------------- study
    def select_study(self, i):
        if not (0 <= i < len(self.studies)):
            return
        self.study = self.studies[i]
        d, sp = self.study.dims, self.study.spacing
        self.cursor = [d[0] // 2, d[1] // 2, d[2] // 2]
        for p in self.slice_panes:
            p.set_study(self.study)
        self.pane_3d.set_study(self.study)
        self._rebuild_label_checks()
        self.lb_study.setText("%s · %s" % (self.study.name, self.study.modality))
        self.lb_dims.setText("%d×%d×%d @ %.2f/%.2f/%.2f mm" % (tuple(d) + tuple(sp)))
        self.lb_codes.setText("i→%s  j→%s  k→%s" % tuple(self.study.codes))
        n_cls = len(self.study.label_ids())
        self.lb_cls.setText("classes %d" % n_cls if n_cls else "classes —")
        self.set_cursor(self.cursor)
        self.lb_msg.setText("%s  ·  %s" % (self.study.name, self.study.source or ""))

    def _rebuild_label_checks(self):
        if self.study is None:
            while self.label_box.count():
                it = self.label_box.takeAt(0)
                if it.widget():
                    it.widget().deleteLater()
            self.label_checks = {}
            lb = QtWidgets.QLabel("데이터 없음")
            lb.setStyleSheet("color:#5f779c;font-style:italic;")
            self.label_box.addWidget(lb)
            self.label_box.addStretch(1)
            return
        while self.label_box.count():
            it = self.label_box.takeAt(0)
            if it.widget():
                it.widget().deleteLater()
        self.label_checks = {}
        ids = self.study.label_ids() if self.study else []
        if not ids:
            lb = QtWidgets.QLabel("annotation 없음")
            lb.setStyleSheet("color:#5f779c;font-style:italic;")
            self.label_box.addWidget(lb)
            return
        for lid in ids:
            hexc = label_hex(lid)
            cb = QtWidgets.QCheckBox(label_name(lid))
            cb.setToolTip("class id %d   %s" % (lid, hexc))
            cb.setChecked(self.label_visible.get(lid, True))
            cb.setStyleSheet("QCheckBox::indicator:checked{background:%s;border:1px solid %s;}"
                             "QCheckBox::indicator{width:11px;height:11px;border:1px solid #3a5c8f;}"
                             % (hexc, hexc))
            cb.toggled.connect(lambda on, i=lid: self._label_toggled(i, on))
            self.label_box.addWidget(cb)
            self.label_checks[lid] = cb
        if self.study is not None and getattr(self.study, "truncated", False):
            warn = QtWidgets.QLabel("… %d개 초과분 생략" % MAX_LABELS)
            warn.setStyleSheet("color:%s;" % C_AMBER)
            self.label_box.addWidget(warn)
        self.label_box.addStretch(1)

    def add_data(self):
        paths, _ = QtWidgets.QFileDialog.getOpenFileNames(
            self, "Add data — 원본과 annotation 을 함께 선택할 수 있습니다", "",
            "Volumes (*.nii *.nii.gz *.nrrd *.seg.nrrd *.nhdr *.hdr);;All files (*)")
        if paths:
            self.open_paths([os.path.normpath(p) for p in paths])

    def add_dicom(self):
        d = QtWidgets.QFileDialog.getExistingDirectory(self, "Add DICOM series folder")
        if d:
            self._load_study(d)

    def _load_study(self, path, select=True):
        if len(self.studies) >= MAX_STUDIES:
            QtWidgets.QMessageBox.information(
                self, "Add data",
                "동시에 열 수 있는 파일은 %d개까지입니다." % MAX_STUDIES)
            return None
        try:
            img, codes = read_volume(path)
        except Exception as err:                                  # noqa: BLE001
            QtWidgets.QMessageBox.critical(self, "Add data", str(err))
            return None
        name = self._stem(path) or os.path.basename(os.path.normpath(path))
        st = Study(name, img, None, codes=codes,
                   modality="DICOM" if os.path.isdir(path) else "volume", source=path)
        self.studies.append(st)
        self.tabs.addTab(st.name, st.modality)
        if select:
            self.tabs.setCurrentIndex(len(self.studies) - 1, force=True)
        return st

    def add_annotation(self):
        if self.study is None:
            return
        path, _ = QtWidgets.QFileDialog.getOpenFileName(
            self, "Add annotation — segmentation", "",
            "Segmentations (*.nii *.nii.gz *.nrrd *.seg.nrrd *.nhdr);;All files (*)")
        if not path:
            return
        try:
            lab, _codes = read_volume(path)
        except Exception as err:                                  # noqa: BLE001
            QtWidgets.QMessageBox.critical(self, "Add annotation", str(err))
            return
        if lab.GetDimensions() != self.study.dims:
            QtWidgets.QMessageBox.warning(
                self, "Add annotation",
                "annotation 격자 %s 가 original %s 과 다릅니다.\n"
                "추론 파이프라인의 resampling 을 확인하세요."
                % (lab.GetDimensions(), self.study.dims))
            return
        self.study.label = cast_to_labelmap(lab)
        self.study.label_source = path
        self.study.invalidate_labels()
        self.tabs.setTabSub(self.tabs.currentIndex(), "volume + label")
        self.select_study(self.tabs.currentIndex())
        self.lb_msg.setText("annotation loaded — %s  (%d classes)"
                            % (os.path.basename(path), len(self.study.label_ids())))

    def delete_all(self):
        """열려 있는 데이터를 모두 화면에서 지운다. 디스크의 파일은 건드리지 않는다."""
        if not self.studies:
            return
        n = len(self.studies)
        if QtWidgets.QMessageBox.question(
                self, "Delete all",
                "화면에 열려 있는 %d개 데이터를 모두 지웁니다.\n"
                "디스크의 파일은 삭제되지 않습니다. 계속할까요?" % n,
                QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
                QtWidgets.QMessageBox.No) != QtWidgets.QMessageBox.Yes:
            return

        self.studies = []
        self.study = None
        self._maximized = None
        self.label_visible = {}
        self.tabs.blockSignals(True)
        self.tabs.clear()
        self.tabs.blockSignals(False)
        for p in self.panes:
            p.show()
        for p in self.slice_panes:
            p.set_study(None)
            p.slider.blockSignals(True)
            p.slider.setRange(0, 0)
            p.slider.blockSignals(False)
        self.pane_3d.set_study(None)
        self._rebuild_label_checks()
        for lb, txt in ((self.lb_study, "—"), (self.lb_dims, "—"),
                        (self.lb_cls, "classes —"), (self.lb_pos, "i — j — k —"),
                        (self.lb_mm, "— mm"), (self.lb_val, "value —"),
                        (self.lb_lab, "label —")):
            lb.setText(txt)
        self.lb_codes.setText("—")
        self.lb_msg.setText("%d개 데이터를 화면에서 지웠습니다 · 파일을 끌어다 놓으면 다시 열립니다" % n)
        self.render_all()

    def close_study(self):
        self.close_study_at(self.tabs.currentIndex())

    def close_study_at(self, i):
        if not (0 <= i < len(self.studies)):
            return
        self.studies.pop(i)
        self.tabs.blockSignals(True)
        self.tabs.removeTab(i)
        self.tabs.blockSignals(False)
        if self.studies:
            self.tabs.setCurrentIndex(min(i, len(self.studies) - 1), force=True)
        else:
            self.study = None
            for p in self.slice_panes:
                p.set_study(None)
            self.pane_3d.set_study(None)
            self._rebuild_label_checks()
            self.lb_study.setText("—")
            self.lb_msg.setText("열려 있는 데이터가 없습니다 · 파일을 끌어다 놓으세요")
            self.render_all()

    # -------------------------------------------------------- drag & drop
    def dragEnterEvent(self, e):
        if e.mimeData().hasUrls():
            e.acceptProposedAction()

    def dragMoveEvent(self, e):
        if e.mimeData().hasUrls():
            e.acceptProposedAction()

    def dropEvent(self, e):
        paths = []
        for url in e.mimeData().urls():
            p = url.toLocalFile()
            if p:
                paths.append(os.path.normpath(p))
        if paths:
            e.acceptProposedAction()
            self.open_paths(paths)

    @staticmethod
    def _stem(path):
        """확장자를 모두 떼어 낸 파일 이름. case01.nii.gz -> case01"""
        b = os.path.basename(os.path.normpath(path))
        for ext in (".nii.gz", ".seg.nrrd", ".nii", ".nrrd", ".nhdr", ".hdr", ".img", ".gz"):
            if b.lower().endswith(ext):
                return b[: -len(ext)]
        return os.path.splitext(b)[0]

    @classmethod
    def _is_label_file(cls, path):
        """파일 이름만 보고 annotation 인지 판단한다."""
        b = os.path.basename(os.path.normpath(path)).lower()
        if ".seg." in b:                       # Slicer 관례: case.seg.nrrd
            return True
        toks = [t for t in re.split(r"[_\-. ]+", cls._stem(path).lower()) if t]
        return any(t in LABEL_WORDS for t in toks)

    @classmethod
    def _match_key(cls, name):
        """원본과 annotation 을 짝지을 때 쓰는 정규화 키.
           GD_001 / GD_001_seg / GD-001-label -> 모두 'gd001'"""
        toks = [t for t in re.split(r"[_\-. ]+", cls._stem(name).lower()) if t]
        toks = [t for t in toks if t not in LABEL_WORDS]
        return "".join(toks)

    def open_paths(self, paths):
        """드롭 · 파일 열기 공통 경로. 원본과 annotation 을 이름으로 짝짓는다."""
        volumes = [p for p in paths if os.path.isdir(p) or not self._is_label_file(p)]
        labels = [p for p in paths if not os.path.isdir(p) and self._is_label_file(p)]

        opened, attached, skipped = [], 0, []
        QtWidgets.QApplication.setOverrideCursor(QtCore.Qt.WaitCursor)
        try:
            for p in volumes:
                if len(self.studies) >= MAX_STUDIES:
                    skipped.append(os.path.basename(p))
                    continue
                st = self._load_study(p, select=False)
                if st is not None:
                    opened.append(st)

            for p in labels:
                key = self._match_key(p)
                target = None
                for st in opened:                            # 같이 드롭한 원본 먼저
                    if self._match_key(st.name) == key:
                        target = st
                        break
                if target is None:                           # 이미 열려 있는 study 중에서
                    for st in self.studies:
                        if self._match_key(st.name) == key:
                            target = st
                            break
                if target is None and len(opened) == 1:      # 원본이 하나뿐이면 그것에
                    target = opened[0]

                if target is not None and self._attach_label(target, p):
                    attached += 1
                elif len(self.studies) < MAX_STUDIES:
                    st = self._load_label_only(p)            # 짝이 없으면 labelmap 단독으로
                    if st is not None:
                        opened.append(st)
                else:
                    skipped.append(os.path.basename(p))
        finally:
            QtWidgets.QApplication.restoreOverrideCursor()

        if opened:
            self.tabs.setCurrentIndex(self.studies.index(opened[0]), force=True)
        elif attached:
            self.select_study(self.tabs.currentIndex())

        msg = []
        if opened:
            msg.append("%d개 volume 열기" % len(opened))
        if attached:
            msg.append("%d개 annotation 연결" % attached)
        if skipped:
            msg.append("%d개 건너뜀 (최대 %d개)" % (len(skipped), MAX_STUDIES))
        if msg:
            self.lb_msg.setText(" · ".join(msg))
        if skipped:
            QtWidgets.QMessageBox.information(
                self, "Add data",
                "동시에 열 수 있는 파일은 %d개까지입니다.\n열지 못한 파일:\n  %s"
                % (MAX_STUDIES, "\n  ".join(skipped[:10])))

    def _load_label_only(self, path):
        """짝을 찾지 못한 annotation 은 자기 자신을 label 로 삼아 색으로 보여 준다."""
        st = self._load_study(path, select=False)
        if st is None:
            return None
        st.label = cast_to_labelmap(st.image)
        st.label_source = path
        st.invalidate_labels()
        st.modality = "labelmap"
        self.tabs.setTabSub(self.studies.index(st), "labelmap")
        return st

    def _attach_label(self, study, path):
        """격자가 맞으면 annotation 으로 붙이고 True 를 돌려준다."""
        try:
            lab, _codes = read_volume(path)
        except Exception:                                     # noqa: BLE001
            return False
        if lab.GetDimensions() != study.dims:
            QtWidgets.QMessageBox.warning(
                self, "Add annotation",
                "%s\nannotation 격자 %s 가 original %s 과 다릅니다."
                % (os.path.basename(path), lab.GetDimensions(), study.dims))
            return False
        study.label = cast_to_labelmap(lab)
        study.label_source = path
        study.invalidate_labels()
        i = self.studies.index(study)
        self.tabs.setTabSub(i, "volume + label")
        return True

    # ----------------------------------------------------------- screenshot
    def _grab_pane(self, pane):
        rw = pane.widget.GetRenderWindow()
        rw.Render()
        w2i = vtk.vtkWindowToImageFilter()
        w2i.SetInput(rw)
        w2i.SetInputBufferTypeToRGB()
        w2i.ReadFrontBufferOff()
        w2i.Update()
        img = w2i.GetOutput()
        dx, dy, _ = img.GetDimensions()
        arr = numpy_support.vtk_to_numpy(img.GetPointData().GetScalars())
        return arr.reshape(dy, dx, 3)

    def _compose_view(self):
        """현재 화면 — 최대화 상태면 그 뷰, 아니면 4-pane 을 한 장으로 합친다."""
        if self._maximized is not None:
            return np.flipud(self._grab_pane(self._maximized))
        tiles = [self._grab_pane(p) for p in
                 (self.pane_axial, self.pane_3d, self.pane_coronal, self.pane_sagittal)]
        h = max(t.shape[0] for t in tiles)
        w = max(t.shape[1] for t in tiles)
        pad = 4
        canvas = np.full((2 * h + pad, 2 * w + pad, 3), 34, np.uint8)
        for n, t in enumerate(tiles):
            r, c = divmod(n, 2)
            y0 = r * (h + pad)
            x0 = c * (w + pad)
            canvas[y0:y0 + t.shape[0], x0:x0 + t.shape[1]] = t
        return np.flipud(canvas)

    def save_screenshot(self):
        if self.study is None:
            return
        path, _ = QtWidgets.QFileDialog.getSaveFileName(
            self, "Save screenshot",
            os.path.join(self._capture_folder(), "%s_view.png" % self.study.name),
            "PNG (*.png);;JPEG (*.jpg)")
        if not path:
            return
        try:
            self._write_image(self._compose_view(), path)
            self.lb_msg.setText("screenshot saved — %s" % path)
        except Exception as err:                                  # noqa: BLE001
            QtWidgets.QMessageBox.critical(self, "Save screenshot", str(err))

    @staticmethod
    def _write_image(rgb, path):
        """확장자에 따라 PNG / JPG 로 저장."""
        rgb = np.ascontiguousarray(np.flipud(rgb).astype(np.uint8))
        h, w, _ = rgb.shape
        img = vtk.vtkImageData()
        img.SetDimensions(w, h, 1)
        va = numpy_support.numpy_to_vtk(rgb.reshape(-1, 3), deep=True,
                                        array_type=vtk.VTK_UNSIGNED_CHAR)
        va.SetNumberOfComponents(3)
        img.GetPointData().SetScalars(va)
        if os.path.splitext(path)[1].lower() in (".jpg", ".jpeg"):
            wr = vtk.vtkJPEGWriter()
            wr.SetQuality(94)
            wr.ProgressiveOff()
        else:
            wr = vtk.vtkPNGWriter()
        wr.SetFileName(path)
        wr.SetInputData(img)
        wr.Write()
        if wr.GetErrorCode() != 0:
            raise IOError("이미지를 저장하지 못했습니다: %s" % path)

    # 이전 이름 호환
    _write_png = _write_image

    # --------------------------------------------------------- interaction
    def set_tool(self, key):
        self.tool = key
        self.lb_msg.setText({
            "pan": "Pan — 뷰 안에서 드래그하면 이동합니다",
            "rotate": "Rotation — 3D 뷰에서 드래그하면 회전합니다",
            "cross": "Crosshair — 2D 뷰를 클릭하면 세 평면이 함께 이동합니다",
            "wl": "W/L — 2D 뷰에서 드래그: 좌우 = window width, 상하 = level",
        }[key])

    def set_cursor(self, ijk):
        if self.study is None or self._updating:
            return
        self._updating = True
        d = self.study.dims
        self.cursor = [int(np.clip(ijk[a], 0, d[a] - 1)) for a in range(3)]
        for p in self.slice_panes:
            p.slice_index = self.cursor[p.orientation]
            p.apply_slice()
        self.report_voxel(self.cursor)
        self._updating = False
        self.render_all()

    def _nudge(self, d):
        p = self._maximized if isinstance(self._maximized, SlicePane) else self.pane_axial
        p.step(d)

    def report_voxel(self, ijk):
        if self.study is None:
            return
        i, j, k = ijk
        v = self.study.image.GetScalarComponentAsDouble(i, j, k, 0)
        w = self.study.voxel_to_world(ijk)
        self.lb_pos.setText("i %d  j %d  k %d" % (i, j, k))
        self.lb_mm.setText("%.1f  %.1f  %.1f mm" % tuple(w))
        self.lb_val.setText("value %g" % v)
        if self.study.label is not None:
            lid = int(self.study.label.GetScalarComponentAsDouble(i, j, k, 0))
            if lid:
                self.lb_lab.setText("label %d  %s" % (lid, label_name(lid)))
            else:
                self.lb_lab.setText("label —")
        else:
            self.lb_lab.setText("label —")

    def set_background(self, name):
        self.bg_name = name
        if name in self.bg_actions:
            self.bg_actions[name].setChecked(True)
        self.pane_3d.set_background(name)
        self.lb_msg.setText("3D 배경: %s" % name)

    def toggle_segment(self, lid):
        """F1~F10 — 해당 클래스만 켜고 끈다."""
        if self.study is None or self.study.label is None:
            self.lb_msg.setText("annotation 이 없습니다")
            return
        if lid not in self.label_checks:
            self.lb_msg.setText("%s 는 이 데이터에 없습니다" % label_name(lid))
            return
        cb = self.label_checks[lid]
        cb.setChecked(not cb.isChecked())
        self.lb_msg.setText("%s %s  (F%d)" %
                            (label_name(lid), "표시" if cb.isChecked() else "숨김", lid))

    def _capture_folder(self):
        """캡처를 저장할 폴더 — annotation 파일이 있는 폴더를 우선한다."""
        st = self.study
        for cand in (getattr(st, "label_source", None), st.source):
            if not cand:
                continue
            if os.path.isdir(cand):
                return cand
            d = os.path.dirname(os.path.abspath(cand))
            if os.path.isdir(d):
                return d
        return os.getcwd()

    def capture_beside_label(self):
        """F12 — 현재 화면을 annotation 파일이 있는 폴더에 JPG 로 저장."""
        if self.study is None:
            return
        folder = self._capture_folder()
        fname = "%s_%s.jpg" % (self.study.name, time.strftime("%Y%m%d_%H%M%S"))
        path = os.path.join(folder, fname)
        try:
            self._write_image(self._compose_view(), path)
        except Exception as err:                                  # noqa: BLE001
            QtWidgets.QMessageBox.critical(self, "Capture (F12)", str(err))
            return
        self.lb_msg.setText("F12 캡처 저장 — %s" % path)

    HOTKEYS = [
        ("F1 ~ F10", "Segment_1 ~ Segment_10 표시 on/off"),
        ("F12", "현재 화면을 JPG 로 저장 (annotation 파일이 있는 폴더)"),
        ("", ""),
        ("L", "annotation 전체 on/off"),
        ("C", "crosshair on/off"),
        ("R", "카메라 · 슬라이스 초기화"),
        ("1 2 3 4", "Axial / 3D / Coronal / Sagittal 최대화"),
        ("Esc", "최대화 해제"),
        ("↑ ↓", "slice 이동"),
        ("", ""),
        ("Ctrl+O", "원본 volume 열기 (여러 개 선택 가능)"),
        ("Ctrl+L", "annotation 열기"),
        ("Ctrl+W", "현재 study 닫기"),
        ("Ctrl+Shift+D", "Delete all — 열려 있는 데이터 전부 지우기"),
        ("Ctrl+S", "화면 저장 (위치를 직접 지정)"),
        ("Ctrl+Q", "종료"),
        ("", ""),
        ("드래그 앤 드롭", "파일을 창에 놓으면 열림 (최대 %d개)" % MAX_STUDIES),
        ("pane 더블클릭", "그 뷰를 최대화 / 복귀"),
        ("마우스 휠", "2D = slice 이동, 3D = 확대·축소"),
    ]

    def show_hotkeys(self):
        dlg = QtWidgets.QDialog(self)
        dlg.setWindowTitle("Hotkey")
        dlg.setStyleSheet(self.styleSheet())
        outer = QtWidgets.QVBoxLayout(dlg)
        outer.setContentsMargins(18, 16, 18, 14)
        outer.setSpacing(10)

        title = QtWidgets.QLabel("설정되어 있는 단축키")
        title.setStyleSheet("font-size:13px;font-weight:600;color:%s;" % C_INK)
        outer.addWidget(title)

        grid = QtWidgets.QGridLayout()
        grid.setHorizontalSpacing(18)
        grid.setVerticalSpacing(5)
        row = 0
        for key, desc in self.HOTKEYS:
            if not key:
                line = QtWidgets.QFrame()
                line.setFrameShape(QtWidgets.QFrame.HLine)
                line.setStyleSheet("color:%s;" % C_EDGE)
                grid.addWidget(line, row, 0, 1, 2)
            else:
                k = QtWidgets.QLabel(key)
                k.setStyleSheet("font-family:'IBM Plex Mono',Consolas,monospace;"
                                "color:%s;font-weight:600;" % C_AMBER)
                d = QtWidgets.QLabel(desc)
                d.setStyleSheet("color:%s;" % C_INK_DIM)
                grid.addWidget(k, row, 0, QtCore.Qt.AlignRight | QtCore.Qt.AlignTop)
                grid.addWidget(d, row, 1)
            row += 1
        outer.addLayout(grid)

        if self.study is not None and self.study.label is not None:
            ids = self.study.label_ids()
            if ids:
                note = QtWidgets.QLabel(
                    "현재 데이터의 클래스: " +
                    ",  ".join("F%d = %s" % (i, label_name(i)) for i in ids if i <= 10))
                note.setWordWrap(True)
                note.setStyleSheet("color:%s;font-size:11px;" % C_INK_DIM)
                outer.addWidget(note)

        btn = QtWidgets.QPushButton("닫기")
        btn.clicked.connect(dlg.accept)
        roww = QtWidgets.QHBoxLayout()
        roww.addStretch(1)
        roww.addWidget(btn)
        outer.addLayout(roww)
        dlg.exec_()

    def toggle_labels(self, on=None):
        self.show_labels = self.act_labels.isChecked() if on is None else on
        for p in self.slice_panes:
            p.apply_slice()
        self.pane_3d.refresh_label_style()
        self.render_all()

    def toggle_crosshair(self, on=None):
        self.show_crosshair = self.act_cross.isChecked() if on is None else on
        for p in self.slice_panes:
            p.update_crosshair()
        self.render_all()

    def _label_toggled(self, lid, on):
        self.label_visible[lid] = on
        for p in self.slice_panes:
            p.refresh_label_lut()
        self.pane_3d.refresh_label_style()
        self.render_all()

    def _label_alpha_changed(self, *_):
        self.label_alpha_2d = self.sl_a2.value() / 100.0
        self.label_alpha_3d = self.sl_a3.value() / 100.0
        for p in self.slice_panes:
            p.refresh_label_lut()
        self.pane_3d.refresh_label_style()
        self.render_all()

    def set_preset(self, name):
        p = PRESETS[name]
        self.preset = name
        self.ww, self.wl = p["ww"], p["wl"]
        for sp in (self.sp_ww, self.sp_wl):
            sp.blockSignals(True)
        self.sp_ww.setValue(self.ww); self.sp_wl.setValue(self.wl)
        for sp in (self.sp_ww, self.sp_wl):
            sp.blockSignals(False)
        for sp in self.slice_panes:
            sp.apply_window_level()
            sp.apply_slice()
        self.pane_3d.apply_transfer()
        self.render_all()

    def _wl_spin_changed(self, *_):
        self.ww, self.wl = self.sp_ww.value(), self.sp_wl.value()
        for p in self.slice_panes:
            p.apply_window_level()
            p.apply_slice()
        self.render_all()

    def _scene_changed(self, *_):
        self.volume_alpha = self.sl_op.value() / 100.0
        self.threshold_scale = self.sl_th.value() / 100.0
        self.pane_3d.apply_transfer()
        self.pane_3d.render()

    def _shade_changed(self, v):
        self.shade = v / 100.0
        amb, dif, spc = shading_params(self.shade)
        self.pane_3d.apply_shading()
        self.pane_3d.render()
        self.lb_msg.setText("shading %d  (ambient %.2f / diffuse %.2f / specular %.2f "
                            "— 밝기 %d~100%%)" % (v, amb, dif, spc, round(amb * 100)))

    def _volume_toggled(self, on):
        self.show_volume = on
        self.pane_3d.set_volume_visible(on)
        self.pane_3d.render()

    def _orient_changed(self, text):
        if self.study is None:
            return
        if text == "RAS":
            self.study.codes = list(CODE_RAS)
        elif text == "LPS":
            self.study.codes = list(CODE_LPS)
        else:
            return
        self.select_study(self.tabs.currentIndex())

    def sync_window_level_from(self, pane):
        w, l = pane.window_level()
        rng = self.study.scalar_range if self.study else (0.0, 255.0)
        span = max(1.0, rng[1] - rng[0])
        self.ww = int(np.clip(w / span * 255.0, 1, 512))
        self.wl = int(np.clip((l - rng[0]) / span * 255.0, -256, 512))
        self.sp_ww.blockSignals(True); self.sp_wl.blockSignals(True)
        self.sp_ww.setValue(self.ww); self.sp_wl.setValue(self.wl)
        self.sp_ww.blockSignals(False); self.sp_wl.blockSignals(False)
        for p in self.slice_panes:
            if p is not pane:
                p.apply_window_level()
            p.apply_slice()
        self.render_all()

    def ww_native(self):
        rng = self.study.scalar_range if self.study else (0.0, 255.0)
        return max(1.0, (rng[1] - rng[0]) * self.ww / 255.0)

    def wl_native(self):
        rng = self.study.scalar_range if self.study else (0.0, 255.0)
        return rng[0] + (rng[1] - rng[0]) * self.wl / 255.0

    def zoom(self, f):
        for p in self.slice_panes:
            p.zoom(f)
        self.pane_3d.zoom(f)

    def reset_views(self):
        self.sl_shade.setValue(int(SHADE_DEFAULT * 100))
        for p in self.slice_panes:
            p.reset_camera()
            p.apply_slice()
        self.pane_3d.reset()
        self.render_all()

    def render_all(self):
        for p in self.panes:
            p.render()

    # 더블클릭 → 해당 pane 최대화 (PPT slide 4)
    def eventFilter(self, obj, ev):
        t = ev.type()
        if t == QtCore.QEvent.MouseButtonDblClick:
            for p in self.panes:
                if obj is p.widget:
                    self._toggle_max(p)
                    return True
        # VTK 위젯은 네이티브 창이라 드롭이 부모로 올라가지 않는다. 여기서 받아 넘긴다.
        elif t in (QtCore.QEvent.DragEnter, QtCore.QEvent.DragMove):
            if ev.mimeData().hasUrls():
                ev.acceptProposedAction()
                return True
        elif t == QtCore.QEvent.Drop:
            if ev.mimeData().hasUrls():
                self.dropEvent(ev)
                return True
        return super().eventFilter(obj, ev)

    def _toggle_max(self, pane):
        if self._maximized is pane:
            self._unmaximize()
            return
        for p in self.panes:
            p.setVisible(p is pane)
        self._maximized = pane
        QtCore.QTimer.singleShot(0, self.render_all)

    def _unmaximize(self):
        for p in self.panes:
            p.show()
        self._maximized = None
        QtCore.QTimer.singleShot(0, self.render_all)


# ===========================================================================
def build_studies(args):
    studies = []
    if args:
        img, codes = read_volume(args[0])
        st = Study(os.path.basename(os.path.normpath(args[0])).split(".")[0],
                   img, None, codes=codes, source=args[0])
        if len(args) > 1:
            lab, _ = read_volume(args[1])
            if lab.GetDimensions() != st.dims:
                raise SystemExit(
                    "annotation 격자 %s 가 original %s 과 다릅니다."
                    % (lab.GetDimensions(), st.dims))
            st.label = cast_to_labelmap(lab)
            st.label_source = args[1]
        studies.append(st)
    else:
        for seed, site, mod in ((11, "AComm", "MRA"), (29, "MCA bif", "MRA"),
                                (47, "ICA siphon", "MRA"), (63, "PComm", "CTA")):
            studies.append(make_phantom(seed, mod, site))
    return studies


def qt_doctor():
    """Qt 가 뜨지 않을 때 원인을 찾기 위한 자가 진단 출력."""
    line = "-" * 62
    print(line)
    print(" CLARUS-N Viewer  self check")
    print(line)
    print(" python      : %s" % sys.version.split()[0])
    print(" executable  : %s" % sys.executable)
    print(" platform    : %s" % sys.platform)
    try:
        import PyQt5
        from PyQt5.QtCore import QT_VERSION_STR, PYQT_VERSION_STR
        print(" PyQt5       : %s   (Qt %s)" % (PYQT_VERSION_STR, QT_VERSION_STR))
        print(" PyQt5 path  : %s" % os.path.dirname(PyQt5.__file__))
    except Exception as err:                                  # noqa: BLE001
        print(" PyQt5       : IMPORT FAILED - %s" % err)
    print(" plugin dir  : %s" % (_QT_PLUGIN_DIR or "NOT FOUND"))

    ok = True
    if _QT_PLUGIN_DIR is None:
        ok = False
        print("\n [!] PyQt5 의 Qt plugins 폴더가 없습니다.")
        print("     PyQt5-Qt5 패키지가 빠졌을 때 생깁니다.")
    else:
        plat = os.path.join(_QT_PLUGIN_DIR, "platforms")
        want = "qwindows.dll" if os.name == "nt" else "libqxcb.so"
        have = sorted(os.listdir(plat)) if os.path.isdir(plat) else []
        print(" platforms   : %s" % (", ".join(have) or "(비어 있음)"))
        if not any(f.startswith(want.split(".")[0]) for f in have):
            ok = False
            print("\n [!] %s 가 없습니다." % want)

    for var in ("QT_PLUGIN_PATH", "QT_QPA_PLATFORM_PLUGIN_PATH",
                "QT_QPA_PLATFORM", "QT_DEBUG_PLUGINS"):
        print(" env %-24s = %s" % (var, os.environ.get(var, "(없음)")))

    try:
        import vtk as _v
        print(" VTK         : %s" % _v.VTK_VERSION)
    except Exception as err:                                  # noqa: BLE001
        ok = False
        print(" VTK         : IMPORT FAILED - %s" % err)

    print(line)
    if ok:
        print(" 필요한 요소는 모두 있습니다.")
        print(" 그래도 창이 뜨지 않으면 repair_windows.bat 을 실행해 Qt 를 다시 설치하세요.")
    else:
        print(" repair_windows.bat 을 실행하면 PyQt5 를 깨끗이 다시 설치합니다.")
    print(line)
    return 0 if ok else 1


def main(argv):
    if "--doctor" in argv or "--check" in argv:
        return qt_doctor()

    args = [a for a in argv[1:] if not a.startswith("-")]
    try:
        studies = build_studies(args)
    except Exception as err:                                      # noqa: BLE001
        traceback.print_exc()
        raise SystemExit("불러오기 실패: %s" % err)

    app = QtWidgets.QApplication(argv)
    app.setApplicationName(APP_NAME)
    app.setApplicationVersion(APP_VERSION)
    win = ClarusViewer(studies)
    win.show()
    return app.exec_()


if __name__ == "__main__":
    sys.exit(main(sys.argv))
