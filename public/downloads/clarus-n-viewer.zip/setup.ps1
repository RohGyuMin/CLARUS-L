# ===========================================================
#  CLARUS-N Viewer - first time setup
#
#  Downloads a PRIVATE copy of Python into .\runtime\python and
#  installs VTK / PyQt5 / numpy into it.
#  Nothing is installed system wide and nothing touches the
#  registry or PATH. Deleting the folder removes everything.
#
#  exit 0 = ok
#  exit 2 = could not download the Python runtime
#  exit 3 = could not install pip
#  exit 4 = could not install VTK / PyQt5 / numpy
# ===========================================================
$ErrorActionPreference = 'Stop'
try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch { }

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $root

$runtime = Join-Path $root 'runtime'
$py      = Join-Path $runtime 'python'
$pyexe   = Join-Path $py 'python.exe'
New-Item -ItemType Directory -Force -Path $runtime | Out-Null

# -----------------------------------------------------------
Write-Host ''
Write-Host '[1/4] Downloading the Python runtime ...'
$zip = Join-Path $runtime 'python-embed.zip'
$got = ''
foreach ($v in '3.12.10', '3.12.9', '3.12.8', '3.12.7', '3.12.6', '3.11.9') {
    $u = "https://www.python.org/ftp/python/$v/python-$v-embed-amd64.zip"
    try {
        Invoke-WebRequest -Uri $u -OutFile $zip -UseBasicParsing
        $got = $v
        break
    } catch { }
}
if ($got -eq '') {
    Write-Host ''
    Write-Host '[!] Could not download the Python runtime from python.org.'
    Write-Host '    Check the internet connection, or a company proxy /'
    Write-Host '    firewall may be blocking www.python.org.'
    exit 2
}
Write-Host "      got Python $got"

# -----------------------------------------------------------
Write-Host '[2/4] Unpacking ...'
if (Test-Path $py) { Remove-Item -Recurse -Force $py }
Expand-Archive -Path $zip -DestinationPath $py -Force
Remove-Item $zip -Force

# The embeddable build ships with site-packages disabled. Turn it on.
Get-ChildItem -Path $py -Filter 'python*._pth' | ForEach-Object {
    $lines = @(Get-Content $_.FullName | ForEach-Object { $_ -replace '^\s*#\s*import\s+site\s*$', 'import site' })
    if ($lines -notcontains 'Lib\site-packages') { $lines += 'Lib\site-packages' }
    if ($lines -notcontains 'import site')       { $lines += 'import site' }
    Set-Content -Path $_.FullName -Value $lines -Encoding ASCII
}
if (-not (Test-Path $pyexe)) {
    Write-Host '[!] python.exe is missing after unpacking.'
    exit 2
}

# -----------------------------------------------------------
Write-Host '[3/4] Installing pip ...'
$getpip = Join-Path $runtime 'get-pip.py'
try {
    Invoke-WebRequest -Uri 'https://bootstrap.pypa.io/get-pip.py' -OutFile $getpip -UseBasicParsing
} catch {
    Write-Host '[!] Could not download get-pip.py from bootstrap.pypa.io.'
    exit 3
}
& $pyexe $getpip --no-warn-script-location --quiet
$rc = $LASTEXITCODE
Remove-Item $getpip -Force -ErrorAction SilentlyContinue
if ($rc -ne 0) {
    Write-Host '[!] pip could not be installed.'
    exit 3
}

# -----------------------------------------------------------
Write-Host '[4/4] Installing VTK, PyQt5 and numpy ...'
Write-Host '      about 150 MB - this is the long step, please wait.'
Write-Host ''
& $pyexe -m pip install --no-warn-script-location --no-cache-dir "PyQt5>=5.15" numpy
if ($LASTEXITCODE -ne 0) { Write-Host '[!] PyQt5 / numpy install failed.'; exit 4 }

# VTK only needs matplotlib for features this viewer does not use,
# so --no-deps keeps the folder about 30 MB smaller.
& $pyexe -m pip install --no-warn-script-location --no-cache-dir --no-deps "vtk>=9.2"
if ($LASTEXITCODE -ne 0) { Write-Host '[!] VTK install failed.'; exit 4 }

# -----------------------------------------------------------
Write-Host ''
Write-Host 'Checking the installation ...'
& $pyexe -c "import vtk, PyQt5, numpy; print('      VTK ' + vtk.VTK_VERSION + '   numpy ' + numpy.__version__)"
if ($LASTEXITCODE -ne 0) { Write-Host '[!] The installed packages do not import.'; exit 4 }

Write-Host ''
Write-Host 'Setup finished.'
exit 0
