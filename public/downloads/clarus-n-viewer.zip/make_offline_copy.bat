@echo off
rem ===========================================================
rem  Make an offline copy of CLARUS-N Viewer
rem
rem  Packs this whole folder - including the private Python
rem  runtime - into one ZIP. Copy that ZIP to a PC with no
rem  internet and no Python, extract it, and the viewer starts
rem  straight away with no download.
rem ===========================================================
setlocal
cd /d "%~dp0"
title CLARUS-N Viewer - make offline copy

echo.
echo ===========================================================
echo   CLARUS-N Viewer  -  make offline copy
echo ===========================================================
echo.

if not exist "runtime\python\python.exe" (
    echo [!] The private runtime is missing.
    echo     Run "CLARUS-N Viewer.bat" once first, so that the
    echo     runtime exists and can be packed.
    echo.
    pause
    exit /b 1
)

if exist "error_log.txt" del "error_log.txt"
if exist "..\CLARUS-N_Viewer_offline.zip" del "..\CLARUS-N_Viewer_offline.zip"

echo Packing ... this takes a few minutes (about 400 MB).
echo.
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "Compress-Archive -Path '%~dp0*' -DestinationPath '%~dp0..\CLARUS-N_Viewer_offline.zip' -CompressionLevel Optimal -Force"
if errorlevel 1 goto :FAIL

echo.
echo ===========================================================
echo   Done.
echo   Made:  %~dp0..\CLARUS-N_Viewer_offline.zip
echo.
echo   Copy that ZIP to the other PC, extract it, and run
echo   "CLARUS-N Viewer.bat" there. No internet, no Python.
echo ===========================================================
echo.
pause
exit /b 0

:FAIL
echo.
echo [!] Packing failed. You can also just copy this whole folder
echo     to the other PC with a USB stick - that works too.
echo.
pause
exit /b 1
