﻿===========================================================
  CLARUS-N Viewer  (포터블 판)
  Python 이 설치되어 있지 않은 PC 에서도 그대로 실행됩니다.
===========================================================

■ 쓰는 법

  1. 이 ZIP 을 오른쪽 클릭 → "압축 풀기" 로 폴더에 풉니다.
     (ZIP 안에서 바로 실행하면 동작하지 않습니다)

  2. 폴더 안의  "CLARUS-N Viewer.bat"  을 더블클릭합니다.

  3. 처음 한 번만 준비 과정이 돕니다.
     이 폴더 안의 runtime 폴더에 전용 Python 을 내려받습니다.
     약 200MB, 3 ~ 10 분 걸립니다.
     PC 에는 아무것도 설치되지 않습니다.
     Program Files, 레지스트리, PATH 를 건드리지 않으므로
     이 폴더만 지우면 흔적 없이 사라집니다.

  4. 두 번째 실행부터는 바로 뜹니다.


■ 인터넷이 없는 PC 에서 쓰려면

  준비 과정에서만 인터넷이 필요합니다. 인터넷이 안 되는 PC 라면:

  1. 인터넷 되는 PC 에서 위 순서대로 한 번 실행해 둡니다.
  2. 같은 폴더의  make_offline_copy.bat  을 실행합니다.
     → 상위 폴더에 CLARUS-N_Viewer_offline.zip 이 만들어집니다.
       (전용 Python 까지 통째로 들어 있어 약 400MB)
  3. 그 ZIP 을 USB 로 옮겨 인터넷 없는 PC 에서 풀고
     "CLARUS-N Viewer.bat" 을 실행하면 바로 뜹니다.

  ZIP 을 만들지 않고 폴더째 USB 로 복사해도 똑같이 됩니다.


■ 파일 여는 방법

  · 프로그램 창에 파일을 끌어다 놓기 (한 번에 여러 개, 최대 20개)
  · "CLARUS-N Viewer.bat" 아이콘 위로 파일을 끌어다 놓기
  · 메뉴 File ▸ Add data

  원본과 annotation 은 파일 이름으로 자동으로 짝지어집니다.
    GD_001.nii.gz   +  GD_001_seg.nii.gz
    CTA_777.nii.gz  +  CTA_777-label.nii.gz
  label / seg / mask / pred / annot / gt 가 이름에 들어 있으면
  annotation 으로 봅니다.

  지원 형식: NIfTI(.nii, .nii.gz), NRRD(.nrrd, .seg.nrrd), DICOM 폴더


■ 자주 쓰는 단축키

  F1 ~ F10      Segment_1 ~ Segment_10 켜고 끄기
  F12           현재 화면을 JPG 로 저장
                (annotation 파일이 있는 폴더에 자동 저장)
  L             annotation 전체 켜고 끄기
  R             화면 초기화
  1 2 3 4       Axial / 3D / Coronal / Sagittal 최대화
  Esc           최대화 해제
  Ctrl+Shift+D  열려 있는 데이터 전부 지우기

  메뉴줄의 Hotkey 를 누르면 전체 목록이 나옵니다.


■ 창이 안 뜰 때

  같은 폴더의  diagnose.bat  을 실행하세요.
  Python · VTK · PyQt5 상태를 확인하고, 콘솔을 켠 채로 프로그램을
  다시 실행해 오류 내용을 화면에 남깁니다.
  error_log.txt 파일이 생겼다면 그 내용도 같이 보여 줍니다.

  준비 과정이 중간에 끊겼다면 "CLARUS-N Viewer.bat" 을 다시
  실행하면 됩니다. 이어서 다시 시도합니다.

  runtime 폴더를 지우고 다시 실행하면 처음부터 새로 받습니다.


■ 폴더 안에 있는 것

  CLARUS-N Viewer.bat      실행 (이것만 쓰면 됩니다)
  make_offline_copy.bat    인터넷 없는 PC 용 ZIP 만들기
  diagnose.bat             문제 확인
  clarusn_viewer.py        프로그램 본체
  launch.py, setup.ps1     실행 · 준비 스크립트
  runtime\                 전용 Python (첫 실행 때 생김)

===========================================================
