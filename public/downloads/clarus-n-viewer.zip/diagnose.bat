@echo off
rem  Run this when the viewer does not appear after starting it.
setlocal
cd /d "%~dp0"
title CLARUS-N Viewer - diagnose

echo.
echo ===========================================================
echo   CLARUS-N Viewer  -  diagnose
echo ===========================================================
echo.

if not exist "runtime\python\python.exe" (
    echo [!] The private runtime is missing.
    echo     Run "CLARUS-N Viewer.bat" once to set it up.
    echo.
    pause
    exit /b 1
)

set "QT_PLUGIN_PATH="
set "QT_QPA_PLATFORM_PLUGIN_PATH="
set "QT_QPA_PLATFORM="

echo ---- self check --------------------------------------------
"runtime\python\python.exe" clarusn_viewer.py --doctor
echo.

if exist "error_log.txt" (
    echo ---- error_log.txt from the last start ---------------------
    type "error_log.txt"
    echo.
)

echo ---- starting with the console visible ----------------------
echo      (any error will stay on screen)
echo.
"runtime\python\python.exe" launch.py
echo.
echo ---- the viewer has closed ---------------------------------
echo.
pause
